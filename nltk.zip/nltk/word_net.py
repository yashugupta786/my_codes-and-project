#wordnet is the largest lexical data set  with that we can look into the synonyms and antonyms
#synsets means synonym set

from nltk.corpus import wordnet
import json
'''synsets means  synoynmous names  
foreg motorcar the synsets for motocar is is car.n.01
and if we require more synoynm we will use the  syn.lemmas() and then the name of that l.name() '''
# syns=wordnet.synsets("motorcar")
# print(syns[0].lemmas)
# synoyms=[]
# antonyms=[]
# final_dict={}
# all_keywords=["update","password","delete"]
# for i in all_keywords:
#     for syn in wordnet.synsets(i):
#         for l in syn.lemmas():
#             synoyms.append(l.name())
#             # if l.antonyms():
#             #     antonyms.append(l.antonyms()[0].name)
#
#
#
#     final_dict[i]=map(str,(list(set(synoyms))))
# print(json.dumps(final_dict))
# #
#
#
#
# #
# # for syn in wordnet.synsets("good"):
#     for l in syn.lemmas():
#         synoyms.append(l.name())
#         if l.antonyms():
#             antonyms.append(l.antonyms()[0].name())
# final_dict["synoynms"]=map(str,list(set(synoyms)))
#
# print final_dict
'''
for findingg the similarity we use the wu palmer algorithm -->
path similarity computes the shortest number of edges from one word sense to another word sense essentially in graph foreg
man vs dog and man vs tree here man is more similar to dog 
sim$_{\text{path}}(c_1, c_2) = \text{pathlen}(c_1, c_2)$

'''
w1=wordnet.synset("change.n.01")#ship.n.01 is the lemma code name
w2=wordnet.synset("remove.n.01")
print(w1.wup_similarity(w2))
w3=wordnet.synset("ship.n.01")
w4=wordnet.synset("boat.n.01")
print(w3.wup_similarity(w4))
w5=wordnet.synset("ship.n.01")
w6=wordnet.synset("cat.n.01")
print(w5.wup_similarity(w6))