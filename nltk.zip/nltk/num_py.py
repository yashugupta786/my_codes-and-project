#numpy means n dimensional array
#memory usage in numpy is less in compare to python list  because size of 1 element =4 bytes and in python everything is object  1 obj=14 bytes
#array method in numpy take list as input
# arrange method act as a range in numpy
#ndim function to find out the dimension
# item size is function to find out the size in the multi dimensional array

import sys
import time
import numpy as np

a=np.array([1,2,3])
print a[0]
print a[1]
print a[2]

size=1000000
l1=range(size)
l2=range(size)
a1=np.arange(size)
a2=np.arange(size)

start=time.time()
result=[(x+y)for x,y in zip(l1,l2)]

print ("python time ",(time.time()-start)*1000)
#numpy

start=time.time()
result =a1+a2
print result
print ("numpy took",(time.time()-start)*1000)

a3=np.array([1,2,3])
a4=np.array([4,5,6])
resul=a3+a4#all operations can pe performed

print resul
#--------------------------basic array operations -------------

a11=np.array([5,6,9])
print a11[2]
#------------2 dimensional array
a12=np.array([[1,2],[3,4],[5,6]])
a13=np.array([[1,3],[1,6],[9,8]],dtype=np.float64)#occupying 8 bytes
print "size",a13.itemsize

print a13.size #returns the total elements in the array
print a13.shape #returns columns and rows

a14=np.array([[1,3],[1,6],[9,8]],dtype=np.complex)
print a14
a15=np.arange(1,5)
print "a15", a15
#linear sequence of number
# ravel() is used to create a one dimensional aray
#sum() is used to calculate the sum(axis=0)
a16=np.linspace(1,5,10)
a17=np.linspace(1,10,20)
print a16
print a17
#----------slicing in numpy--------------------
a18=np.array([[6,7,8,],[1,2,3],[9,3,2]])
print  "a18",a18
print a18[0:1]
print a18[0:2,2] #always takes first and the second last
#it will print [8,3]
print "new numpy", a18 [0:3,2]
print "slicing ", a18[0:3,1]
print a18[2,2]
print a18[0,0]
#------------------

final_dict={}
text="i am yashu gupta and i am working as technical associate in genpact headstrong"

def split_line(text):
    print text

    word = text.split(",")
    print word
    print type(word)
    final_dict["text"]=word
    print final_dict


split_line(text)