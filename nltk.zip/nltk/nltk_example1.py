from nltk.tokenize import sent_tokenize,word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer,SnowballStemmer
from nltk.tokenize import PunktSentenceTokenizer
import nltk

'''
when sentence is tokenize from paragraph then each sentence is called as token
when words are tokenize from sentence then each word is called as token 
 The process of converting data to something a computer can understand is referred to as "pre-processing.
 useless words--->stop words foreg umm,huh ,uh"
'''

Example_test="Hello Mr. Brahm, how are you doing today? The weather is great, and Python is awesome. The sky is pinkish-blue. You shouldn't eat cardboard."
example_Sent ="This is a sample sentence, showing off the stop words filtration. I am a Pythoner and i love to do things in pythoning and this is the best thing in the pythoned .I love to eating things "
# # print(sent_tokenize(Example_test)
# print(word_tokenize(Example_test))

stop_words=stopwords.words('english')
print(stop_words)
ps=PorterStemmer()
print(type(stop_words))
word_token=word_tokenize(example_Sent)
print(word_token)
filter_Sentence =[]
final_dict={}
for new_word in word_token:
    if new_word not in stop_words and new_word not in ('!',',',':','.',''):
        filter_Sentence.append(new_word)




# filter_Sentence = [word for word in word_token if word not in stop_words]



final_dict["filtered data"]=filter_Sentence
print(final_dict)
print(type(filter_Sentence))

#stemming of the words
'''
stemming -->root stem

# '''
# ps=PorterStemmer()
# example_words=[]
# example_words=["python","pythoner","pyhtoning","pythoned","helping","wering" ,"wassed","aged"]
# for stemming_example  in example_words:
#     print(ps.stem(stemming_example))



# new_test_data=nltk.tokenize(Example_test)
dvv=PunktSentenceTokenizer()# it is use for tagging
tokenized_data=dvv.tokenize(Example_test)
# print("new_data",tokenized_data)
def process_content():
    try:
        for i in tokenized_data[:5]:
            words=nltk.word_tokenize(i)
            new_tag_sentence =nltk.pos_tag(words)
            print(new_tag_sentence)
    except Exception as e :
        print (str(e))


process_content()