#lemmatizing -->similar to stemming only the end result will be actual word in this we can use the part of speeech tag
from nltk.stem import WordNetLemmatizer
lemmatizer= WordNetLemmatizer()
print(lemmatizer.lemmatize("cats"))
example_words=["cats","rats","actions","better","best","reached"]
for new_data in example_words:
    lemmatising_data=lemmatizer.lemmatize(new_data,pos='n')
    print(lemmatising_data)
