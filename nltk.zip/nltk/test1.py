n = ["Michael", "Lieberman"]
# Add your function here
def join_strings(words):
    result=""
    for i in words:
        # print(i)
        result=result + i
    print(result)



join_strings(n)