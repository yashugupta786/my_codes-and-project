'''
NER is the name entity  recognition .
the main idea behind the ner to pull out the entities like people,place,things,monetary figures  etc
'''
import nltk
from nltk.corpus import state_union

from nltk.tokenize import PunktSentenceTokenizer


train_text ="This is a sample sentence, showing off the stop words filtration. I am a Pythoner and i love to do things in pythoning and this is the best thing in the pythoned .I love to eating things "
Example_test="Hello Mr. Brahm, how are you doing today? The weather is great, and Python is awesome. The sky is pinkish-blue. You shouldn't eat cardboard."

# train_text = state_union.raw("2005-GWBush.txt")
#
# sample_text = state_union.raw("2006-GWBush.txt")
# print sample_text
# custom_sent_tokenizer = PunktSentenceTokenizer()
#
# tokenized = custom_sent_tokenizer.tokenize(train_text)

# def process():
#     try:
#         for i in tokenized[5:]:
#             words = nltk.word_tokenize(i)
#             tagged = nltk.pos_tag(words)
#             print tagged
#             namedEnt = nltk.ne_chunk(tagged, binary=True)
#             namedEnt.draw()
#     except Exception as e:
#         print(str(e))
#
#
# process()
sentence = "I am sitting in Apple. I found a bug in apple"
dvv = PunktSentenceTokenizer()
tokenized_data = dvv.tokenize(sentence)

def process_content():
    try:
        for i in tokenized_data[:5]:
            words = nltk.word_tokenize(i)
            new_tag_sentence = nltk.pos_tag(words)
            print(new_tag_sentence)
            gg=nltk.ne_chunk(new_tag_sentence)
            print(gg)
            gg.draw()
    except Exception as e:
        print (str(e))



process_content()