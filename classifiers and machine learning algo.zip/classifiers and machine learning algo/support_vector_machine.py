'''

support vector machine (svm)-:working  in vector space 
the most popular machine learning algo 
its a binary classsifier 
there are 2 groups called as postive and negative groups   
it finds the best decision boundary by separrating the postive negative 
WE DO THE INTUATION ON THE BASIS OF THE DATA POINT USING THE DECSION BOUNDARY OR HYPERPLANE
'''
import numpy as np
from sklearn import preprocessing, cross_validation, neighbors,svm
import pandas as pd

df = pd.read_csv('breast-cancer-wisconsin.data.txt')
df.replace('?',-99999, inplace=True)

df.drop(['id'], 1, inplace=True)

X = np.array(df.drop(['class'], 1))
y = np.array(df['class'])

X_train, X_test, y_train, y_test = cross_validation.train_test_split(X, y, test_size=0.2)

print(X_train)
clf = svm.SVC()


clf.fit(X_train, y_train)
# confidence = clf.score(X_test, y_test)
# print(confidence)

example_measures = np.array([[4,2,1,1,1,2,3,2,1],[4,2,1,2,2,1,2,1,2]])
example_measures = example_measures.reshape(len(example_measures), -1)
prediction = clf.predict(example_measures)
print(prediction)