import sklearn
from sklearn import tree
import numpy as np
#decision Tree
from sklearn.datasets import load_iris # data set which include the flowers and from that we can do the training and testing
iris=load_iris()
test_idx=[0,50,100]
# train_target=np.delete(iris.target,test_idx)
# train_data=np.delete(iris.data,test_idx,axis=0)
# print(train_target)
# print(train_data)
# clf=tree.DecisionTreeClassifier()
# clf.fit(features,labels)

#training data

# print("featurenames",iris.feature_names)
# print("featuretargets",iris.target_names)
# print("feature_data",iris.data)
# print("feature_target",iris.target)
'''
KNN algorithim  it find the nearest neighbour and vote for that after
how to find nearest neighbour for thet Euclidean distance formula is used 
Euclidean find the distance between 2 points and use the pythagoras theorem 





'''
x=iris.data
y=iris.target
print("all data",y)
clf=tree.DecisionTreeClassifier()

clf.fit(x,y)
# print(iris.target)
'''
separting traini9ng and training data 

'''
x = np.array([6.2,3.4,5.4,2.3])

print(clf.predict(x))
