import sklearn
from sklearn import tree
import random
import numpy as np
#decision Tree
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris # data set which include the flowers and from that we can do the training and testing
from sklearn.cross_validation import train_test_split
from sklearn.neighbors import KNeighborsClassifier


iris=load_iris()

X=iris.data
y=iris.target
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.5)
'''
writing ourr own classifier using the same pipeline 

'''

class yashuKNN():
    def fit(self,X_train,y_train):
        self.X_train=X_train
        self.y_train=y_train
        pass
    def predict(self,X_test):
        predictions=[]
        for row in X_test:
            label=random.choice(self.y_train)
            predictions.append(label)
        return  predictions
        pass

clf0=yashuKNN()
clf=tree.DecisionTreeClassifier()
clf1=KNeighborsClassifier()

clf.fit(X_train,y_train)
clf1.fit(X_train,y_train)
clf0.fit(X_train,y_train)

# print(iris.target)
'''
separting traini9ng and training data 

'''
predictions3=clf.predict(X_test)
predictions12=clf1.predict(X_test)
predictions=clf0.predict(X_test)
print(accuracy_score(y_test,predictions3))
print(accuracy_score(y_test,predictions12))
print(accuracy_score(y_test,predictions))