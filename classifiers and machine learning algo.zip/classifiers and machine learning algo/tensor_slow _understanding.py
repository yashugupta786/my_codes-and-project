import tensorflow as tf
import numpy as np
a=tf.constant(5)
b=tf.constant(6)
c=tf.add(a,b)
print(c)
sess=tf.Session()
print(sess.run(c))

d=tf.placeholder(tf.float32)
e=tf.placeholder(tf.float32)

print(sess.run(d+e,{d:4,e:14}))
l = tf.Variable(5)
m= tf.Variable(6)
sess = tf.Session()
sess.run(tf.global_variables_initializer())

result = sess.run(a + b)

print(result)