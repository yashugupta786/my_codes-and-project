'''when to use nearest neigbour --check which is the nearest neighbor to apoint 
What is the K in this 
If k=2 
then it means it find 2 closest  neighbours  points  and its based on the euclidean distance algo  .
It is not effiecent as other if the  the data set is very large 
 dataset used  UCI data set for machine learning ]
 
 squareroot of  (q1-p1)^2+(q2-p2)^2
 
'''
'''
Learning the parameters of a prediction function and testing it on the same data is a methodological mistake:
 a model that would just repeat the labels of the samples that it has just seen would 
have a perfect score but would fail to predict anything useful on yet-unseen data. This situation is called overfitting.
TO AVOIDE overfiting we use the concept of cross validation  we divide the data into 3 parts 
1 training will proceed on the training set 
2 ) evaluation is done on the validation set 
3) final evaluation is done on the test set  
'''




import numpy as np
from sklearn import preprocessing ,cross_validation ,neighbors
import pandas as pd
df= pd.read_csv('breast-cancer-wisconsin.data.txt')
df.replace('?',-99999,inplace=True)
df.drop(['id'],1,inplace=True)
X=np.array(df.drop(['class'],1))
y=np.array(df['class'])
X_train,X_test,y_train, y_test=cross_validation.train_test_split(X,y,test_size=0.2)#suffling the data
clf = neighbors.KNeighborsClassifier()
clf.fit(X_train,y_train)#takes features,labels

accuracy=clf.score(X_test,y_test)
print(accuracy)
new_test_data=np.array([4,2,1,1,1,2,3,2,1])
print(clf.predict(new_test_data))