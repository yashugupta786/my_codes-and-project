import tensorflow as tf
import numpy as np

a=tf.constant(5.0)
b=tf.constant(6.0)
d= tf.placeholder(tf.float32)
e= tf.placeholder(tf.float32)
g=np.array([[5.0,5.0]])
h= np.array([[2.0],[2.0]])
i=tf.matmul(g,h)
f= tf.multiply(d,e)
c=tf.add(a,b)
with tf.Session() as sess:
    print(sess.run(c))
    print(sess.run(f,{d:4,e:5}))
    print(sess.run(i))