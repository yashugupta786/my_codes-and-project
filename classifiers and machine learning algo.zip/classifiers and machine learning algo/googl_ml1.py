import sklearn
from sklearn import tree
#decision Tree
from sklearn.datasets import load_iris # data set which include the flowers and from that we can do the training and testing
iris=load_iris()
from sklearn import svm
# print(iris)
# print("featurenames",iris.feature_names)
# print("featuretargets",iris.target_names)
# print("feature_data",iris.data[0])
# print("feature_target",iris.target[0])

'''
0 is for bumpy 
1 is for smooth 
'''
features=[[140,4],[130,4],[150,5],[170,5]]
print(type (features))
labels=[0,0,1,1]
'''
here zero is for apple and 1 is for orange
in features we will define the training data
'''
#training a classifier
clf=tree.DecisionTreeClassifier()
SVM=svm.SVC()
clf.fit(features,labels)
SVM.fit(features,labels)
'''
clf.fit  is the function is used for the training
and clf.predict is the function that is used for prediction of output by feeding thee test data
'''
print(clf.predict([135,4]))
print(clf.predict([165,5]))
print(clf.predict([140,5]))
print(SVM.predict([166,4]))