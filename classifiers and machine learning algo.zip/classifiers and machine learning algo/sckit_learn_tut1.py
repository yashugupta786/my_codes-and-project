'''
ALl naive classifiers have  High bias and low variance classifiers
KNN have low bias and high variance 

'''
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn import svm
from sklearn.naive_bayes import MultinomialNB,BernoulliNB,GaussianNB
#support vector Machine
'''
It labled the groups and divide them into groups 
'''
# a=[1,2,3,4,5,6,7,8,9,0]
# print(a[:-1])It means all the elemnts except the last
digits=datasets.load_digits()
# print(digits.data)
print(digits.target)
# # print(digits.images[0])
clf =svm.SVC(gamma=1,C=100)


print(len(digits.data))
x,y=digits.data[:-10],digits.target[:-10]
print("all x",x)
print("all y ",y)


clf.fit(x,y)#training of data
# print(x)
# print(digits.data[-1])
mnb=MultinomialNB()
clf1=mnb.fit(x,y)
gnb=GaussianNB()
cf2=gnb.fit(x,y)
bnb=BernoulliNB()
cf3=bnb.fit(x,y)
#we sill use 1796 as learning data and last element is used for the testing

print("predictions:",clf.predict(digits.data[-3]))
# print("predictions",clf1.predict(digits.data[-3]))
#
# print("predictions--",cf2.predict(digits.data[-3]))
# print("predictions:::",cf3.predict(digits.data[-3]))
# if cf2.predict(digits.data[-3])==cf3.predict(digits.data[-3]):
#     print("results from the machine learning is  true")
plt.imshow(digits.images[-3],cmap=plt.cm.gray_r,interpolation='nearest')
plt.show()

