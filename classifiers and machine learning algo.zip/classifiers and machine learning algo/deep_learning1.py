# import numpy as np
# input_data=np.array([2,3])
# weights={"node0":np.array([1,1]),"node1":np.array([-1,1]),"output": np.array([2,-1])}
# print(type(weights))
# node_0_value=(input_data*weights['node0']).sum()
# node_1_value=(input_data*weights['node1']).sum()
# print(node_0_value)
# print(node_1_value)
# print("all weights",weights['output'][0])
# hidden_output1= node_0_value*weights['output'][0]
# hidden_output2= node_1_value*weights['output'][1]
# new_output=hidden_output1+hidden_output2
# print("outcome",new_output)
import os
from sklearn.datasets import  load_svmlight_file
print(load_svmlight_file())