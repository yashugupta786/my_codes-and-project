from kiteconnect import KiteTicker, KiteConnect
import pandas as pd
import pytz
import concurrent.futures
import io
import requests
import os.path as path
import configparser
import pymongo
import datetime as dt
from src.Price_action_techniques.config import sector_indices
from src.Price_action_techniques.config import *
from src.Price_action_techniques.Indicators import *

CONFIG_DIR = path.abspath(path.join(__file__, "../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    key = str(config_obj.get("Kiteconfig", "kite_api_key"))
    access_token = str(config_obj.get("Kiteconfig", "kite_access_token"))
    mongo_port = (config_obj.get("mongo_details", "MongoPort"))
    mongo_db = (config_obj.get("mongo_details", "Database_name"))
    daily_data = (config_obj.get("mongo_details", "Daily_datastore"))
    nse_url = str(config_obj.get("URLS", "url"))
    nse_dump = str(config_obj.get("mongo_details", "NSE_datadump"))
    mongo_db_connect = str(config_obj.get("mongo_details", "Database_name"))
except Exception as e:
    raise Exception("Config file error: " + str(e))
# ------------------Authentication--------------

client = pymongo.MongoClient("localhost", 27017)
kite = KiteConnect(api_key=key)
kite.set_access_token(access_token)

client = pymongo.MongoClient("localhost", 27017)
kite = KiteConnect(api_key=key)
kite.set_access_token(access_token)

# ----DataLoader--------------------------
# -----------
db = client[mongo_db_connect]
nse_coll=db[nse_dump]
symbols_list=nse_coll.find({},{"Symbol":1,"Company Name":1,"_id":False})
symbols_list=list(symbols_list)
symbol_list_nse=[i["Symbol"] for i in symbols_list]
company_name=[i["Company Name"] for i in symbols_list]
stock_info=dict(zip(symbol_list_nse,company_name))
def diff_in_values(val1, val2, threash_hold_p):
    diff = abs(val1-val2)
    diffp=diff*100/val1

    return diffp > threash_hold_p, diffp


def getOHOCSame(symbol):

    res_df=pd.DataFrame()
    df = get_Kitedata(symbol, 0, "15minute", kite)
    for index, row in df.head(2).iterrows():
        isDifferentLow,_ = diff_in_values(row['open'], row['low'], 0.001)
        isDifferentHigh,_ = diff_in_values(row['open'], row['high'], 0.001)

        if not isDifferentLow:
            res_df=res_df.append({"time":row['date'],"Type": "Open-Low" ,"Symbol":  row['Name'],"Open": row['open'], "High": row['high'] ,"Low": row['low'], "Close":row['close']}, ignore_index=True)
            # lstTD = f"Open=Low,{dictoloh['date']},{symbol},{dictoloh['open']},{dictoloh['low']},{dictoloh['high']}".split(",")
            # staap_writer.writerow(lstTD)
            #
        if not isDifferentHigh:
            res_df=res_df.append({"time":row['date'],"Type": "Open-High" ,"Symbol":  row['Name'],"Open": row['open'], "High": row['high'] ,"Low": row['low'], "Close":row['close']},ignore_index=True)

            # lstTD = f"Open=High,{dictoloh['date']},{symbol},{dictoloh['open']},{dictoloh['low']},{dictoloh['high']}".split(",")
            # staap_writer.writerow(lstTD)
    # res_df.to_csv(r'Results/openingTrend.csv')
    return res_df
def schedule_job_stocks(symbol_list_nse):
    res_df=pd.DataFrame()
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        results = executor.map(getOHOCSame,symbol_list_nse)
    res_df=res_df.append(list(results), ignore_index=True)
    res_df["Company name"] = res_df["Symbol"].map(stock_info)
    return res_df


result=schedule_job_stocks(symbol_list_nse)
result.to_csv(r'Results/openingTrend.csv',index=False)