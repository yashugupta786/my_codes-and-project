from src.Price_action_techniques.Indicators import *

import os.path as path
import configparser
import pymongo


CONFIG_DIR = path.abspath(path.join(__file__, "../../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    key = str(config_obj.get("Kiteconfig", "kite_api_key"))
    access_token = str(config_obj.get("Kiteconfig", "kite_access_token"))
    mongo_port = (config_obj.get("mongo_details", "MongoPort"))
    mongo_db = (config_obj.get("mongo_details", "Database_name"))
    daily_data = (config_obj.get("mongo_details", "Daily_datastore"))
    nse_url = str(config_obj.get("URLS", "url"))
    nse_dump = str(config_obj.get("mongo_details", "NSE_datadump"))
    mongo_db_connect = str(config_obj.get("mongo_details", "Database_name"))
    Intraday_Selection = str(config_obj.get("mongo_details", "Intraday_Selection"))
    Pivot_data = str(config_obj.get("mongo_details", "Pivot_data"))
except Exception as e:
    raise Exception("Config file error: " + str(e))
# ------------------Authentication--------------

client = pymongo.MongoClient("localhost", 27017)

db = client[mongo_db_connect]
Pivot_col=db[Pivot_data]

def pivot_check(ticker,df):
    df=df.copy()
    close=df['close'].iloc[-1]
    records=Pivot_col.find({"Name":ticker})
    records=list(records)[0]
#     {"Pivot":P , "Support1":S1, "Support2":S2, "Support3":S3, "Resistance1":R1, "Resistance2":R2, "Resistance3":R3}
    levels=[]
    levels.append(records['Support3'])
    levels.append(records['Support2'])
    levels.append(records['Support1'])
    levels.append(records['Pivot'])
    levels.append(records['Resistance1'])
    levels.append(records['Resistance2'])
    levels.append(records['Resistance3'])
    level_up=[i for i in levels if i>close]
    level_low = [i for i in levels if i <= close]
    if len(level_up)==0:
        return "Above R3"

    near_up=min(level_up, key=lambda x: x - close)
    near_low=min(level_low, key=lambda x: close - x)
    if (near_up-close)>(close-near_low):
        return True

    return False


def intra_strategy(ticker,df):
    df= df.copy()
    if vwap(df):
        res_pivot=pivot_check(ticker, df)
        if isinstance(res_pivot, str):
            return {"vwap_stoc_pivot":"Above R3"}

        if res_pivot:
            STOCHRSId, STOCHRSIk = stoc_rsi(df)
            STOCHRSId = STOCHRSId.tolist()[-3:]
            STOCHRSIk = STOCHRSIk.tolist()[-3:]
            slope_k = linregress(range(len(STOCHRSIk)), STOCHRSIk)[0]
            slope_d = linregress(range(len(STOCHRSId)), STOCHRSId)[0]
            if slope_k>slope_d>0:
                return {"vwap_stoc_pivot":"Buy"}
            else:
                return {"vwap_stoc_pivot":"Skip"}
    return {"vwap_stoc_pivot":"Skip"}

