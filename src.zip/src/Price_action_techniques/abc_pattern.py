import pandas as pd
import datetime as dt
import pytz
def getabcinfo(stockname,df):
    df=df.copy()
    final_res = {'LowerBand': None, '50MA': None, 'abc': None}

    # print("Processing++++++++", stockname)
    # df = get_Kitedata(stockname, 180, "day")
    try:
        if len(df)>1:
            df['UpperBand']=df["close"].rolling(20).mean()+df['close'].rolling(20).std()*2
            df['LowerBand']=df["close"].rolling(20).mean()-df['close'].rolling(20).std()*2
            df['50MA']=df["close"].rolling(50).mean()
            df=df.tail(1)
            # df['Date'] = df['Date'].apply(convert_seconds)

        #     df=df[(abs(df['LowerBand']-df['50MA'])<5) & (df['Close']>df['Open']) & (df["Close"]-5>df['LowerBand']) & (df['LowerBand']>df['Open']) & (df["Close"]-5>df['50MA']) & (df['50MA']>df['Open'])]
            df=df[((abs(df['close']-df['50MA'])/df['close'])*100<1.0) & ((abs(df['close']-df['LowerBand'])/df['close'])*100<1.0)]

            # df['date'] = pd.to_datetime(df['date']).apply(lambda x: x.replace(tzinfo=None))

            if len (df)>0:
                df = df.tail(1)
                response=df.head(1).to_dict(orient='records')[0]
                # response['date']
                final_res['LowerBand']=response['LowerBand']
                final_res['50MA'] = response['50MA']
                final_res['abc'] ="Yes"
        # print("-----------------------processed--------------------",stockname)
        return final_res
    except Exception as e:
        print(stockname)
        print("Exception: "+str(e))
        return final_res

    # else:
    #     print("-----------------------processed--------------------", stockname)
    #     return final_res








