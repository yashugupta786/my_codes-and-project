from kiteconnect import KiteTicker,KiteConnect
import pandas as pd
import datetime as dt
import io
import requests
url = "https://www1.nseindia.com/content/equities/EQUITY_L.csv"
import pytz
IST = pytz.timezone('Asia/Kolkata')

def instrumentLookup(kite, symbol):
    try:
        instrument_dump = kite.instruments("NSE")
        instrument_df = pd.DataFrame(instrument_dump)

        return instrument_df[instrument_df.tradingsymbol == symbol].instrument_token.values[0]
    except:
        return -1

def utc_to_time(time, timezone='Asia/Kolkata'):
    return time.replace(tzinfo=pytz.utc).astimezone(pytz.timezone(timezone))
def get_Kitedata(ticker, period, interval,kite):
    instrument = instrumentLookup(kite, ticker)

    if instrument== -1:
        return  pd.DataFrame()
    data = pd.DataFrame(kite.historical_data(instrument, dt.date.today() - dt.timedelta(period), dt.date.today(), interval))

    data['Name']=ticker
    if interval=="day":
        data['date']=data['date'].map(utc_to_time)
    return data


sector_indices=[
"NIFTY AUTO",
"NIFTY BANK",
"NIFTY CONSUMPTION",
"NIFTY ENERGY",
"NIFTY FIN SERVICE",
"NIFTY FMCG",
"NIFTY INFRA",
"NIFTY IT",
"NIFTY MEDIA",
"NIFTY METAL",
"NIFTY PHARMA",
"NIFTY PSE",
"NIFTY PSU BANK",
"NIFTY PVT BANK",
"NIFTY REALTY"
]