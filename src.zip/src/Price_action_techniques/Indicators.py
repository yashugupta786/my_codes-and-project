import time
import numpy as np
import talib

import pandas as pd
import talib as ta

import traceback
import pandas_ta

from scipy.stats import linregress

class Trade_indicators(object):
    def __init__(self):

        pass
    def RSI(self,data, window=14, adjust=False):
        if len(data)<1:
            return None
        data=data.copy()
        delta = data['close'].diff(1).dropna()
        loss = delta.copy()
        gains = delta.copy()
        gains[gains < 0] = 0
        loss[loss > 0] = 0
        gain_ewm = gains.ewm(com=window - 1, adjust=adjust).mean()
        loss_ewm = abs(loss.ewm(com=window - 1, adjust=adjust).mean())

        RS = gain_ewm / loss_ewm
        RSI = 100 - 100 / (1 + RS)
        res= round(RSI.tolist()[-1],2)
        if res>55 and res <72:
            return "Strong buy"
        elif res>25 and res <35:
            return "Strong buy / Oversold"
        elif res>72 :
            return "Strong Sell / Overbought"
        elif (res>35 and res <40) or (res>50 and res <55) :
            return "Buy"
        elif res>40 and res <50:
            return "Sidewise"
        else:
            return None


        return None
    def morning_star(self,data):
        morning_star_df = talib.CDLMORNINGSTAR(data['open'], data['high'], data['low'], data['close'])
        data['Morning Star'] = morning_star_df
        list_mrng=data['Morning Star'].tolist()[-1]
        if list_mrng!=0:
            return {"morning_star":"pattern form"}
        else:
            return {"morning_star":"not form"}

    def slope(self,x1, y1, x2, y2):
        m = (y2 - y1) / (x2 - x1)
        return m

    def get_adx(self,df):
        df=df.copy()
        if len(df)<1:
            return None
        adx = ta.ADX(df['high'], df['low'], df['close'], timeperiod=20)
        adx=[round(i, 2) for i in adx.tolist()[-4:]]
        slope=linregress(range(len(adx)), adx)[0]
        # slope=[self.slope(i-1,adx[i-1],i,adx[i] ) for i in  range(len(adx)-1) if i >0 ]
        # poscount= len([val for val  in slope  if val>0])
        # negcount = len([val for val in slope if val < 0])

        res = adx[-1]
        if res>15 and slope>0 :
            return "Movement"
        return "No Movement"


'''
    def get_adx(self,df , lookback=14):
        high=df['high']
        low = df["low"]
        close = df['close']
        plus_dm = high.diff()
        minus_dm = low.diff()
        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm > 0] = 0

        tr1 = pd.DataFrame(high - low)
        tr2 = pd.DataFrame(abs(high - close.shift(1)))
        tr3 = pd.DataFrame(abs(low - close.shift(1)))
        frames = [tr1, tr2, tr3]
        tr = pd.concat(frames, axis=1, join='inner').max(axis=1)
        atr = tr.rolling(lookback).mean()

        plus_di = 100 * (plus_dm.ewm(alpha=1 / lookback).mean() / atr)
        minus_di = abs(100 * (minus_dm.ewm(alpha=1 / lookback).mean() / atr))
        dx = (abs(plus_di - minus_di) / abs(plus_di + minus_di)) * 100
        adx = ((dx.shift(1) * (lookback - 1)) + dx) / lookback
        adx_smooth = adx.ewm(alpha=1 / lookback).mean()
        return  adx_smooth'''


"""     def ADX(self,df):
        df=df.copy()
        def getCDM(df):
            dmpos = df["high"].iloc[-1] - df["high"].iloc[-2]
            dmneg = df["low"].iloc[-2] - df["low"].iloc[-1]
            if dmpos > dmneg:
                return dmpos
            else:
                return dmneg

        def getDMnTR(df):
            DMpos = []
            DMneg = []
            TRarr = []
            n = round(len(df) / 14)
            idx = n
            while n <= (len(df)):
                dmpos = df["high"].iloc[n - 1] - df["high"].iloc[n - 2]
                dmneg = df["low"].iloc[n - 2] - df["low"].iloc[n - 1]

                DMpos.append(dmpos)
                DMneg.append(dmneg)

                a1 = df["high"].iloc[n - 1] - df["high"].iloc[n - 2]
                a2 = df["high"].iloc[n - 1] - df["close"].iloc[n - 2]
                a3 = df["low"].iloc[n - 1] - df["close"].iloc[n - 2]
                TRarr.append(max(a1, a2, a3))

                n = idx + n

            return DMpos, DMneg, TRarr

        def getDI(df):
            DMpos, DMneg, TR = getDMnTR(df)
            CDM = getCDM(df)
            POSsmooth = (sum(DMpos) - sum(DMpos) / len(DMpos) + CDM)
            NEGsmooth = (sum(DMneg) - sum(DMneg) / len(DMneg) + CDM)

            DIpos = (POSsmooth / (sum(TR) / len(TR))) * 100
            DIneg = (NEGsmooth / (sum(TR) / len(TR))) * 100

            return DIpos, DIneg

        def getADX(df):
            DIpos, DIneg = getDI(df)

            dx = (abs(DIpos - DIneg) / abs(DIpos + DIneg)) * 100

            ADX = dx / 14
            return ADX

        return (getADX(df))"""
def supertrend(data):
    data=data.copy()
    data['strend'] = pandas_ta.supertrend(data['high'], data['low'], data['close'])['SUPERT_7_3.0']
    data['dir'] = np.where((data['strend'] > 0.00), np.where((data['low'] < data['strend']), 'down', 'up'), np.NaN)
    trend = "skip"
    if data['dir'].iloc[-1] == "up" and data['dir'].iloc[-2] == "up":
        trend = "up"
    if data['dir'].iloc[-1] == "down" and data['dir'].iloc[-2] == "down":
        trend = "down"
    return {"Trend":trend}


def get_pivots(df):
    High= df['high'].iloc[-1]
    Low=df['low'].iloc[-1]
    Close=df['close'].iloc[-1]
    # Pivot
    P = round((High + Low + Close) / 3,2)

    # Support
    S1 =round( P - (.382 * (High - Low)),2)

    # Support
    S2 = round(P - (.618 * (High - Low)),2)

    # Support
    S3 = round(P - (1 * (High - Low)),2)

    # Resistance
    R1 = round(P + (.382 * (High - Low)),2)

    # Resistance
    R2 =round( P + (.618 * (High - Low)),2)

    # Resistance
    R3 = round(P + (1 * (High - Low)),2)

    return {"Pivot":P , "Support1":S1, "Support2":S2, "Support3":S3, "Resistance1":R1, "Resistance2":R2, "Resistance3":R3}


def vwap(data):
    data=data.copy()
    if len(data)==0:
        return pd.DataFrame()
    data.set_index('date', inplace=True)
    close=data['close'].iloc[-1]
    open=data['open'].iloc[-1]
    if close> pandas_ta.vwap(data['high'], data['low'], data['close'], data['volume']).tolist()[-1] and close>open:
        return True

    return False

def stoc_rsi(data):
    data=data.copy()
    data.set_index('date', inplace=True)
    storsi_df= pandas_ta.stochrsi(data['close'])
    # print(storsi_df)
    return storsi_df.STOCHRSId_14_14_3_3, storsi_df.STOCHRSIk_14_14_3_3




def moving_avg_50(ticker,df):
    df=df.copy()
    df.set_index('date',inplace=True)
    sma50 = pandas_ta.ma("sma", df.close, length=50)
    if df['close'].iloc[-1]>sma50.tolist()[-1]:
        return {"ma_50":"up"}
    else:
        return {"ma_50":"down"}

def get_SL(ticker,df):

    atr=pandas_ta.atr( df.high, df.low, df.close)
    sma44 = pandas_ta.ma("sma", df.close, length=44)
    if df['close'].iloc[-1] > sma44.tolist()[-1]:
        return {"Stoploss": df.close.iloc[-2]-(5*atr.iloc[-2])}
    else:
        return {"Stoploss": df.close.iloc[-2]+(5*atr.iloc[-2])}
    



