def candle_strength(df1):
    daily_half = int(len(df1["close"]) / 2)
    if round(df1["close"].iloc[-1], 2) > round(df1["close"].iloc[0], 2) and round(df1["close"].iloc[-1], 2) > round(
            df1["close"].iloc[daily_half], 2):
        candle_strength= "Strongly Bullish"

    elif round(df1["close"].iloc[-1], 2) > round(df1["close"].iloc[0], 2):
        if round(df1["close"].iloc[-1], 2) < round(df1["close"].iloc[daily_half], 2):
            candle_strength= "partially Bullish"
        else:
            candle_strength = None
    else:
        candle_strength = "Bearish"
    return candle_strength
def movingAvg(item,df1):
    df1=df1.copy()
    response_dic={}
    try:
        df1["44_SMA"] = df1["close"].rolling(window=44, min_periods=1).mean()
        final_value=round(df1["close"].iloc[-1] - df1["44_SMA"].iloc[-1], 2)
        if df1["close"].iloc[-1] > df1["open"].iloc[-1]:
            response_dic["Candle Type"] = "Green candle"
        else:
            response_dic["Candle Type"] = "Red candle"
        if round(final_value)<=20 and  round(final_value)>=-5 and df1["close"].iloc[-1]>=30:
            exact_touch_point=((df1["low"].iloc[-1]-df1["44_SMA"].iloc[-1])/df1["low"].iloc[-1])*100
            if round(exact_touch_point,2)>=0 and round(exact_touch_point,2)<=2.0:
                response_dic["% MA close to Candle"]=round(exact_touch_point,2)
                response_dic["IS 44"]="YES"
                candle_strngth=candle_strength(df1)
                response_dic["Candle Strength"]=candle_strngth

                response_dic["44 SMA"] = round(df1["44_SMA"].iloc[-1])

            elif round(exact_touch_point, 2) >= -2.0 and round(exact_touch_point, 2) <= 0:
                response_dic["% MA close to Candle"] = round(exact_touch_point, 2)
                response_dic["IS 44"] = "YES"
                candle_strngth = candle_strength(df1)
                response_dic["Candle Strength"] = candle_strngth

                response_dic["44 SMA"] = round(df1["44_SMA"].iloc[-1])
            else:
                response_dic["% MA close to Candle"] =None
                response_dic["IS 44"] = "NO"
                candle_strngth = None
                response_dic["Candle Strength"] = candle_strngth

        else:
            response_dic.update({"Candle Strength":None,"% MA close to Candle":None,"44 SMA":None,"IS 44":None})
            return  response_dic


    except Exception as e:
        print(str(e))
        print("In Exception: "+item)

    return response_dic



