
from datetime import datetime
import datetime as dt
import numpy as np



def convert_seconds(seconds):
    return datetime.fromtimestamp(seconds).strftime('%Y-%m-%d')


def getdoublebottom(stockname,df):
    df=df.copy()
    stockname=stockname.strip()
    res = None
    try:
        df.rename(columns ={'date': 'Date','open':'Open','high':'High','low':'Low','close':'Close','volume':"Volume"},  inplace = True)
        ticker_df = df.dropna()
        ticker_df = ticker_df.reset_index()
        x_data = df.index.tolist()
        y_data = df['Low']
        x = np.linspace(0, max(df.index.tolist()), max(df.index.tolist()) + 1)

        pol = np.polyfit(x_data, y_data, 17)

        y_pol = np.polyval(pol, x)
        data = y_pol

        min_max = np.diff(np.sign(np.diff(data))).nonzero()[0] + 1  # local min & max
        l_min = (np.diff(np.sign(np.diff(data))) > 0).nonzero()[0] + 1  # local min
        l_max = (np.diff(np.sign(np.diff(data))) < 0).nonzero()[0] + 1  # local max
        delta = 10

        dict_i = dict()
        dict_x = dict()

        df_len = len(ticker_df.index)

        for element in l_min:
            l_bound = element - delta
            u_bound = element + delta
            x_range = range(l_bound, u_bound + 1)
            dict_x[element] = x_range

            y_loc_list = list()
            for x_element in x_range:

                if x_element > 0 and x_element < df_len:
                    # y_loc_list.append(ticker_df.Low.iloc[x_element])
                    y_loc_list.append(ticker_df.Low.iloc[x_element])
                    # print(y_loc_list)
                    # print('ticker_df.Low.iloc[x_element]', ticker_df.Low.iloc[x_element])
            dict_i[element] = y_loc_list
        max_delta = 10

        max_dict_i = dict()
        max_dict_x = dict()

        df_len = len(ticker_df.index)

        for element in l_max:
            l_bound = element - max_delta
            u_bound = element + max_delta
            x_range = range(l_bound, u_bound + 1)
            max_dict_x[element] = x_range

            y_loc_list = list()
            for x_element in x_range:

                if x_element > 0 and x_element < df_len:
                    # y_loc_list.append(ticker_df.Low.iloc[x_element])
                    y_loc_list.append(ticker_df.Low.iloc[x_element])
                    # print(y_loc_list)
                    # print('ticker_df.Low.iloc[x_element]', ticker_df.Low.iloc[x_element])
            max_dict_i[element] = y_loc_list
        # unique_bottoms = set(suspected_bottoms)
        # last_minindex = max(unique_bottoms)
        last_minindex = list(dict_i)[-1]
        last_minivalue = ticker_df.Close.iloc[last_minindex]
        sec_last_minindex = list(dict_i)[-2]
        sec_last_minivalue = ticker_df.Close.iloc[sec_last_minindex]
        last_maxindex = list(max_dict_i)[-1]
        last_maxivalue = ticker_df.Close.iloc[last_maxindex]
        sec_last_maxindex = list(max_dict_i)[-2]
        sec_last_maxivalue = ticker_df.Close.iloc[sec_last_maxindex]

        if last_minindex > last_maxindex > sec_last_minindex > sec_last_maxindex and last_minivalue < last_maxivalue and sec_last_minivalue < sec_last_maxivalue:

            get_days=ticker_df.Date.iloc[last_minindex]>= dt.date.today() - dt.timedelta(2)
            #     print("double bottom detected at " +ticker_df.Date.iloc[last_minindex] )
            if sec_last_maxivalue > last_maxivalue:
                if sec_last_maxivalue - last_maxivalue < 5 and sec_last_minivalue - last_minivalue<5 and get_days:
                    # print(stockname+" double bottom detected at " + ticker_df.Date.iloc[last_minindex])
                    res= { "Double Bottom": "Yes"  }
            else:

                # print(stockname+" double bottom detected at " + ticker_df.Date.iloc[last_minindex])
                if abs(sec_last_minivalue - last_minivalue)<5 and get_days:
                    res= { "Double Bottom": "Yes" }
        # if last_minindex>last_maxindex>sec_last_minindex>sec_last_maxindex and last_minivalue<last_maxivalue and sec_last_minivalue<sec_last_maxivalue:
        #     print("double bottom detected at " +ticker_df.Date.iloc[last_minindex] )
        if last_maxindex > last_minindex > sec_last_maxindex and last_minivalue < last_maxivalue and last_minivalue < ticker_df['Low'].tolist()[-1]:
            # print(stockname+ " double bottom about to occur plz buy if price around  " + last_minivalue)
            res= {"Double Bottom": "About to reach"}
    except Exception as e:
        print(stockname)
        print("Exception: "+str(e))
        # print("FailedURL: "+URL)
    if not res:
        res= {"Double Bottom":None}
    # print("in double bottom")
    # print(res)
    return res


