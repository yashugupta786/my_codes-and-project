import pandas as pd
import datetime as dt
def isSupport(df, i):
    support = (df['low'][i] < df['low'][i - 1] )& (df['low'][i] < df['low'][i + 1] )& (df['low'][i + 1] < df['low'][i + 2]) & (df['low'][i - 1] < df['low'][i - 2])
    return support


def isResistance(df, i):
    resistance = (df['high'][i] > df['high'][i - 1] )& (df['high'][i] > df['high'][i + 1]) & (df['high'][i + 1] > \
                 df['high'][i + 2]) & (df['high'][i - 1] > df['high'][i - 2])
    return resistance

def remove_close_values(dic):
    new_dic = {}
    new_list=[]
    for k, v in dic.items():
        if v in new_list:
            continue
        for k2, v2 in dic.items():
            if v2 in new_list:
                continue
            if k!= k2 and (abs(v - v2) / v)  <=0.005  :
                new_dic[k] = (v + v2) / 2
                new_list.append(v)
                new_list.append(v2)
                break
            else:
                new_dic[k] = v

    return new_dic
#
def intechange(sup_dic, res_dic,close, open,df):
    new_supdic={}
    new_resdic={}
    for k,v in res_dic.items():
        # if v>open:
        #     continue
        new_df=df[((df["close"] -v)>0 )]
        for idx, row in new_df.iterrows():
            date=row['date']
            next_day=df[df["date"]==date + dt.timedelta(1)]
            second_day = df[df["date"] == date + dt.timedelta(2)]
            current_day= df[df["date"] == date]
            if len(next_day)>0 and len(second_day)>0:
                if next_day['close'].iloc[0]>v and second_day['close'].iloc[0]>v :
                    new_supdic[k] = v

            elif 2*(v-current_day['open'].iloc[0]) < (current_day['close'].iloc[0]-current_day['open'].iloc[0]):
                new_supdic[k] = v

    for k, v in sup_dic.items():
        # if v<open:
        #     continue
        for idx, row in  df[(( v-df["close"])>0 )].iterrows():
            date = row['date']
            next_day = df[df["date"] == date + dt.timedelta(1)]
            second_day = df[df["date"] == date + dt.timedelta(2)]
            current_day = df[df["date"] == date]
            if len(next_day) > 0 and len(second_day) > 0 :
                if next_day['close'].iloc[0] < v and second_day['close'].iloc[0] < v:
                    new_resdic[k] = v
            elif  2 * (current_day['open'].iloc[0]-v ) < (current_day['open'].iloc[0] - current_day['close'].iloc[0]):
                new_resdic[k] = v
    sup_dic.update(new_supdic)
    res_dic.update(new_resdic)
    sup_dic = {k: v for k, v in sup_dic.items() if v <= open}
    res_dic = {k: v for k, v in res_dic.items() if v > open}
    if len(sup_dic)>5:
        sup_dic= dict(sorted(sup_dic.items(),key=lambda x:x[0],reverse = True)[:5])
    else:
        pass
    if len(res_dic) > 5:
        res_dic=dict(sorted(res_dic.items(),key=lambda x:x[0],reverse = True)[:5])
    else:
        pass
    return  sup_dic,res_dic



def get_support_old(symbol, ticker_df=None):
    ticker_df=ticker_df.copy()
    # ticker_df=ticker_df[:-1]
    if len(ticker_df) < 1:
        return {"On Support": None, "On Breakout": None,
            "Current Support": None, "Current Resistance": None, "Support Margin": None, "Resistance Margin": None}
    levels_support = []
    level_resist = []
    for i in range(2, ticker_df.shape[0] - 2):
        if isSupport(ticker_df, i):
            levels_support.append((ticker_df['date'][i], ticker_df['low'][i]))
        elif isResistance(ticker_df, i):
            level_resist.append((ticker_df['date'][i], ticker_df['high'][i]))
    #     current_low=round(ticker_df['low'][-1],2)
    current_low = ticker_df['low'].tolist()[-1]
    current_high = ticker_df['high'].tolist()[-1]
    current_open = ticker_df['open'].tolist()[-1]
    current_close = ticker_df['close'].tolist()[-1]
    pre_close = ticker_df['close'].tolist()[-2]
    resistance_list = [round(level[1], 2) for level in level_resist]
    resist_date = [level[0] for level in level_resist]
    sup_dic = dict(zip([level[0] for level in levels_support], [round(level[1], 2) for level in levels_support]))
    res_dic = dict(zip(resist_date, resistance_list))
    # new_sup_dic=remove_close_values(sup_dic)
    # new_res_dic=remove_close_values(res_dic)




    breakout=None
    current_resistance = None
    if len(res_dic) > 0:
        current_resistance = min(list(res_dic.values())[-3:], key=lambda x: abs(x - current_close))
        # current_resistance = res_dic[list(res_dic.keys())[0]]

        if pre_close < current_resistance < current_close:
            breakout = "Yes"
            BO_val = current_resistance
            # res_time = sorted(res_dic.keys())[-1]
        else:
            breakout = None
            BO_val = None
            res_time = None
        if current_resistance > current_close:
            res_diff = round(((current_resistance - current_close) / current_close) * 100, 2)


    else:
        current_resistance = None
        breakout = None
        BO_val = None
        res_time = None


    sup_dic, res_dic=intechange(sup_dic, res_dic,current_close,current_open,  ticker_df)

    # updated_sup_dic={k: v for k, v in sup_dic.items() if v <= current_close}
    # for key in res_dic.keys():
    #     if res_dic[key]<current_close and res_dic[key] not in updated_sup_dic.values() :
    #         updated_sup_dic[key]= res_dic[key]
    # updated_res_dic = {k: v for k, v in res_dic.items() if v >= current_close}
    # for key in sup_dic.keys():
    #     if sup_dic[key] > current_close and sup_dic[key] not in updated_res_dic.values():
    #         updated_res_dic[key] = sup_dic[key]


    support_list = list(sup_dic.values())
    # new_support_list=[]



    supp_diff=None
    res_diff=None

    if len(sup_dic) > 0:
        support_list=[i for i in support_list if i<=current_close]
        current_support = min(support_list, key=lambda x:  current_close-x)
        supp_diff = round(((current_close - current_support) / current_close) * 100, 2)
    else:
        current_support = None

    if len(res_dic) > 0 and  not breakout:
        if not current_support:
            res_list=res_dic.values()
            # res_list
        else:
            res_list=[i for i in res_dic.values() if abs(i-current_support)/i>=0.01]

        current_resistance =  min(res_list, key=lambda x:abs(x-current_close))
        # current_resistance = res_dic[list(res_dic.keys())[0]]

        if pre_close < current_resistance < current_close:
            breakout = "Yes"
            BO_val = current_resistance
            # res_time = sorted(res_dic.keys())[-1]
        if current_resistance>current_close:
            res_diff=round(((current_resistance-current_close)/current_close)*100,2)
    if breakout=="Yes" and current_resistance in support_list:
        support_list.remove(current_resistance)


#     df = pd.DataFrame()
#     df['support_list'] = support_list
#     df['change'] = (abs(current_low - df['support_list']) / current_low) * 100
# # IT GIVES TIME TOO "Res_time": res_time   ,"Support Value": row['support_list'],"BO_Val": BO_val
#     for index, row in df.iterrows():
    if supp_diff is not None and supp_diff < 0.5:
        return { "On Support": "Yes",  "On Breakout": breakout,
                 "Current Support": current_support,
                "Current Resistance": current_resistance, "Support Margin": supp_diff, "Resistance Margin": res_diff}
    else:
        pass
    if not breakout:
        return { "On Support": None,  "On Breakout": breakout,
                "Current Support": current_support, "Current Resistance": current_resistance, "Support Margin": supp_diff, "Resistance Margin": res_diff }
    return {"On Support": None, "On Breakout": breakout,
            "Current Support": current_support, "Current Resistance": current_resistance, "Support Margin": supp_diff, "Resistance Margin": res_diff}


