import numpy as np
import talib
from itertools import compress
import traceback

candle_rankings = {
        "CDL3LINESTRIKE_buy": 1,
        "CDL3LINESTRIKE_sell": 2,
        "CDL3BLACKCROWS_buy": 3,
        "CDL3BLACKCROWS_sell": 3,
        "CDLEVENINGSTAR_buy": 4,
        "CDLEVENINGSTAR_sell": 4,
        "CDLTASUKIGAP_buy": 5,
        "CDLTASUKIGAP_sell": 5,
        "CDLINVERTEDHAMMER_buy": 6,
        "CDLINVERTEDHAMMER_sell": 6,
        "CDLMATCHINGLOW_buy": 7,
        "CDLMATCHINGLOW_sell": 7,
        "CDLABANDONEDBABY_buy": 8,
        "CDLABANDONEDBABY_sell": 8,
        "CDLBREAKAWAY_buy": 10,
        "CDLBREAKAWAY_sell": 10,
        "CDLMORNINGSTAR_buy": 12,
        "CDLMORNINGSTAR_sell": 12,
        "CDLPIERCING_buy": 13,
        "CDLPIERCING_sell": 13,
        "CDLSTICKSANDWICH_buy": 14,
        "CDLSTICKSANDWICH_sell": 14,
        "CDLTHRUSTING_buy": 15,
        "CDLTHRUSTING_sell": 15,
        "CDLINNECK_buy": 17,
        "CDLINNECK_sell": 17,
        "CDL3INSIDE_buy": 20,
        "CDL3INSIDE_sell": 56,
        "CDLHOMINGPIGEON_buy": 21,
        "CDLHOMINGPIGEON_sell": 21,
        "CDLDARKCLOUDCOVER_buy": 22,
        "CDLDARKCLOUDCOVER_sell": 22,
        "CDLIDENTICAL3CROWS_buy": 24,
        "CDLIDENTICAL3CROWS_sell": 24,
        "CDLMORNINGDOJISTAR_buy": 25,
        "CDLMORNINGDOJISTAR_sell": 25,
        "CDLXSIDEGAP3METHODS_buy": 27,
        "CDLXSIDEGAP3METHODS_sell": 26,
        "CDLTRISTAR_buy": 28,
        "CDLTRISTAR_sell": 76,
        "CDLGAPSIDESIDEWHITE_buy": 46,
        "CDLGAPSIDESIDEWHITE_sell": 29,
        "CDLEVENINGDOJISTAR_buy": 30,
        "CDLEVENINGDOJISTAR_sell": 30,
        "CDL3WHITESOLDIERS_buy": 32,
        "CDL3WHITESOLDIERS_sell": 32,
        "CDLONNECK_buy": 33,
        "CDLONNECK_sell": 33,
        "CDL3OUTSIDE_buy": 34,
        "CDL3OUTSIDE_sell": 39,
        "CDLRICKSHAWMAN_buy": 35,
        "CDLRICKSHAWMAN_sell": 35,
        "CDLSEPARATINGLINES_buy": 36,
        "CDLSEPARATINGLINES_sell": 40,
        "CDLLONGLEGGEDDOJI_buy": 37,
        "CDLLONGLEGGEDDOJI_sell": 37,
        "CDLHARAMI_buy": 38,
        "CDLHARAMI_sell": 72,
        "CDLLADDERBOTTOM_buy": 41,
        "CDLLADDERBOTTOM_sell": 41,
        "CDLCLOSINGMARUBOZU_buy": 70,
        "CDLCLOSINGMARUBOZU_sell": 43,
        "CDLTAKURI_buy": 47,
        "CDLTAKURI_sell": 47,
        "CDLDOJISTAR_buy": 49,
        "CDLDOJISTAR_sell": 51,
        "CDLHARAMICROSS_buy": 50,
        "CDLHARAMICROSS_sell": 80,
        "CDLADVANCEBLOCK_buy": 54,
        "CDLADVANCEBLOCK_sell": 54,
        "CDLSHOOTINGSTAR_buy": 55,
        "CDLSHOOTINGSTAR_sell": 55,
        "CDLMARUBOZU_buy": 71,
        "CDLMARUBOZU_sell": 57,
        "CDLUNIQUE3RIVER_buy": 60,
        "CDLUNIQUE3RIVER_sell": 60,
        "CDL2CROWS_buy": 61,
        "CDL2CROWS_sell": 61,
        "CDLBELTHOLD_buy": 62,
        "CDLBELTHOLD_sell": 63,
        "CDLHAMMER_buy": 65,
        "CDLHAMMER_sell": 65,
        "CDLHIGHWAVE_buy": 67,
        "CDLHIGHWAVE_sell": 67,
        "CDLSPINNINGTOP_buy": 69,
        "CDLSPINNINGTOP_sell": 73,
        "CDLUPSIDEGAP2CROWS_buy": 74,
        "CDLUPSIDEGAP2CROWS_sell": 74,
        "CDLGRAVESTONEDOJI_buy": 77,
        "CDLGRAVESTONEDOJI_sell": 77,
        "CDLHIKKAKEMOD_buy": 82,
        "CDLHIKKAKEMOD_sell": 81,
        "CDLHIKKAKE_buy": 85,
        "CDLHIKKAKE_sell": 83,
        "CDLENGULFING_buy": 84,
        "CDLENGULFING_sell": 91,
        "CDLMATHOLD_buy": 86,
        "CDLMATHOLD_sell": 86,
        "CDLHANGINGMAN_buy": 87,
        "CDLHANGINGMAN_sell": 87,
        "CDLRISEFALL3METHODS_buy": 94,
        "CDLRISEFALL3METHODS_sell": 89,
        "CDLKICKING_buy": 96,
        "CDLKICKING_sell": 102,
        "CDLDRAGONFLYDOJI_buy": 98,
        "CDLDRAGONFLYDOJI_sell": 98,
        "CDLCONCEALBABYSWALL_buy": 101,
        "CDLCONCEALBABYSWALL_sell": 101,
        "CDL3STARSINSOUTH_buy": 103,
        "CDL3STARSINSOUTH_sell": 103,
        "CDLDOJI_buy": 104,
        "CDLDOJI_sell": 104
    }

def recognize_candlestick(symbol, df):
    df=df.copy()
    """
    Recognizes candlestick patterns and appends 2 additional columns to df;
    1st - Best Performance candlestick pattern matched by www.thepatternsite.com
    2nd - # of matched patterns
    """
    try:
        if 'candlestick_pattern' in df.columns:
            if str(df['candlestick_pattern'][-1]) == 'nan':
                pass
                #print("none")

            if str(df['candlestick_pattern'][-1]) != "skip" and str(df['candlestick_pattern'][-1]) != "" and str(df['candlestick_pattern'][-1]) != "nan":
                return df
        else:
           df['candlestick_pattern'] = ""
           df['candlestick_pattern_trend'] = "skip"
           df['candlestick_match_count'] = np.nan

        op = df['open'].astype(float)
        hi = df['high'].astype(float)
        lo = df['low'].astype(float)
        cl = df['close'].astype(float)

        candle_names = talib.get_function_groups()['Pattern Recognition']

        # patterns not found in the patternsite.com
        exclude_items = ('CDLCOUNTERATTACK',
                         'CDLLONGLINE',
                         'CDLSHORTLINE',
                         'CDLSTALLEDPATTERN',
                         'CDLKICKINGBYLENGTH',
                         #'CDL3STARSINSOUTH', 'CDLDOJISTAR', 'CDLUPSIDEGAP2CROWS', 'CDLADVANCEBLOCK', 'CDL2CROWS',
                         #'CDLBREAKAWAY',
                         )

        include_items = ('CDLABANDONEDBABY','CDL3WHITESOLDIERS','CDLEVENINGSTAR','CDL3OUTSIDE','CDLDRAGONFLYDOJI','CDL2CROWS','CDL3INSIDE','CDL3OUTSIDE','CDLDARKCLOUDCOVER','CDL3INSIDE','CDLHANGINGMAN','CDLRISEFALL3METHODS','CDLRISEFALL3METHODS','CDLENGULFING','CDLENGULFING','CDL3LINESTRIKE','CDLSHOOTINGSTAR','CDLXSIDEGAP3METHODS','CDLXSIDEGAP3METHODS','CDLMORNINGSTAR','CDLUPSIDEGAP2CROWS','CDLINVERTEDHAMMER','CDLPIERCING','CDLGRAVESTONEDOJI','CDL3STARSINSOUTH','CDLHARAMICROSS','CDLHARAMICROSS','CDLUNIQUE3RIVER','CDLHARAMI','CDLHARAMI','CDLHAMMER','CDLEVENINGDOJISTAR','CDLMORNINGDOJISTAR','CDLRICKSHAWMAN')

        candle_names = [candle for candle in candle_names if candle not in exclude_items]
        #candle_names = [candle for candle in candle_names if candle in include_items]
        # candle_names=['CDLSHOOTINGSTAR']
        # create columns for each candle
        for candle in candle_names:
            # below is same as;
            # df["CDL3LINESTRIKE"] = talib.CDL3LINESTRIKE(op, hi, lo, cl)
            df[candle] = getattr(talib, candle)(op, hi, lo, cl)
            if int(df[candle].iloc[-1]) == 1:
                print(symbol, candle)

        #df['candlestick_pattern'] = ""
        #df['candlestick_pattern_trend'] = "skip"
        #df['candlestick_match_count'] = np.nan
        for index, row in df.iterrows():
            if str(row['candlestick_pattern'])!="skip" and str(row['candlestick_pattern'])!=""  and str(row['candlestick_pattern'])!="nan":
                continue

            # no pattern found
            if len(row[candle_names]) - sum(row[candle_names] == 0) == 0:
                df.loc[index,'candlestick_pattern'] = "NO_PATTERN"
                df.loc[index, 'candlestick_match_count'] = 0
            # single pattern found
            elif len(row[candle_names]) - sum(row[candle_names] == 0) == 1:
                # buy pattern 100 or 200
                if any(row[candle_names].values > 0):
                    pattern = list(compress(row[candle_names].keys(), row[candle_names].values != 0))[0]
                    df.loc[index, 'candlestick_pattern'] = pattern
                    df.loc[index, 'candlestick_pattern_trend'] = "buy"
                    df.loc[index, 'candlestick_match_count'] = 1
                # sell pattern -100 or -200
                else:
                    pattern = list(compress(row[candle_names].keys(), row[candle_names].values != 0))[0]
                    df.loc[index, 'candlestick_pattern'] = pattern
                    df.loc[index, 'candlestick_pattern_trend'] = "sell"
                    df.loc[index, 'candlestick_match_count'] = 1
            # multiple patterns matched -- select best performance
            else:
                # filter out pattern names from bool list of values
                patterns = list(compress(row[candle_names].keys(), row[candle_names].values != 0))
                container = []
                for pattern in patterns:
                    if row[pattern] > 0:
                        container.append(pattern + '_buy')
                    else:
                        container.append(pattern + '_sell')
                rank_list = [candle_rankings[p] for p in container]
                if len(rank_list) == len(container):
                    rank_index_best = rank_list.index(min(rank_list))
                    df.loc[index, 'candlestick_pattern'] = container[rank_index_best].split("_")[0]
                    df.loc[index, 'candlestick_pattern_trend'] = container[rank_index_best].split("_")[1]
                    df.loc[index, 'candlestick_match_count'] = len(container)
        # clean up candle columns
        cols_to_drop = candle_names
        df.drop(cols_to_drop, axis = 1, inplace = True)


        # Todo: Need to test below code properly to further improve the error
        """"
        for index, row in df.iterrows():
            candle_type=row['candlestick_pattern']
            candle_prediction=row['candlestick_pattern_trend']
            trend=row['supertrend_final']
            key = f"{symbol}-{candle_type}-{trend}-{candle_prediction}"
            if key in dfCandleValidation.index:
                df.loc[index, 'candlestick_pattern'] = "skip"
                df.loc[index, 'candlestick_pattern_trend'] = "skip"
                df.loc[index, 'candlestick_match_count'] = np.nan

        """
        df['candlestick_pattern_trend'] = df['candlestick_pattern_trend'].replace(np.nan, 'skip', regex=True)
        if str(df['candlestick_pattern'].iloc[-1]) == 'nan':
            print("none")

        return {"candlestick_pattern":df['candlestick_pattern'].iloc[-1], "candlestick_pattern_trend":df['candlestick_pattern_trend'].iloc[-1], "candlestick_match_count":df['candlestick_match_count'].iloc[-1]}
    except Exception as e:
        error_string = traceback.format_exc()
        print(f"{error_string} for symbol : {symbol}")

