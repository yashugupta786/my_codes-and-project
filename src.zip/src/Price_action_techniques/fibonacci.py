ratios = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1]
def get_fibonacci(symbol, df ):
    df=df.copy()
    if len(df) < 1:
        return {"Symbol":symbol,"0":None, "0.236":None, "0.382":None, "0.5":None, "0.618":None, "0.786":None, "1":None}
    highest_swing = -1
    lowest_swing = -1
    for i in range(1 ,df.shape[0 ] -1):
        if df['high'][i] > df['high'][ i -1] and df['high'][i] > df['high'][ i +1] :
            # and \
            #                 (highest_swing == -1 or df['high'][i] > df['high'][highest_swing])
            highest_swing = i
        if df['low'][i] < df['low'][i - 1] and df['low'][i] < df['low'][i + 1] :
            # and (
            #                 lowest_swing == -1 or df['low'][i] < df['low'][lowest_swing])
            lowest_swing = i

    levels = {}
    max_level = df['high'].tolist()[highest_swing]
    min_level = df['low'].tolist()[lowest_swing]
    for ratio in ratios:
        if highest_swing > lowest_swing:  # Uptrend
            levels["fib "+str(round(ratio*100))] = max_level - (max_level - min_level) * ratio
        else:  # Downtrend
            levels["fib "+str(round(ratio*100))] = min_level + (max_level - min_level) * ratio

    return levels