import numpy as np
import pandas_ta
import math
from scipy.stats import linregress
def weekly_moving_avg(ticker,df):
    df=df.copy()
    df.set_index('date',inplace=True)
    sma50 = pandas_ta.ma("sma", df.close, length=50)
    matrend=None
    sma = [round(i, 2) for i in sma50.tolist()[-10:]]
    slope = linregress(range(len(sma)), sma)[0]
    res = sma[-1]
    if math.isnan(res):
        matrend = "up"
        return matrend ,res,df.close.iloc[-1]
    if res<=df.close.iloc[-1] and slope > 0:
        matrend="up"
    return matrend,res,df.close.iloc[-1]




