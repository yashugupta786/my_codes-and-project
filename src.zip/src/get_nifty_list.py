import pandas as pd
nifty_df=pd.read_csv(r"C:\Users\Deepam22\Desktop\stock_project\4_10_21_backup\stock_analysis-master\src\ind_nifty200list.csv")
niflty_list=nifty_df['Symbol']
stock_list=pd.read_csv(r"C:\Users\Deepam22\Desktop\stock_project\4_10_21_backup\stock_analysis-master\src\Results\selected_swing_stocks2022_02_03.csv")
stock_list=stock_list[stock_list["Name"].isin(niflty_list)]
stock_list.to_csv(r"C:\Users\Deepam22\Desktop\stock_project\4_10_21_backup\stock_analysis-master\src\Results\nifty_list_3_feb.csv")