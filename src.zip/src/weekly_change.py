from kiteconnect import KiteTicker, KiteConnect
import pandas as pd
import pytz
import concurrent.futures
import io
import requests
import os.path as path
import configparser
import pymongo
import datetime as dt
from src.Price_action_techniques.config import sector_indices
from src.Price_action_techniques.config import *
from src.Price_action_techniques.Indicators import *
from src.Price_action_techniques.vwap_rsi_pivot_stategy import *
CONFIG_DIR = path.abspath(path.join(__file__, "../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    key = str(config_obj.get("Kiteconfig", "kite_api_key"))
    access_token = str(config_obj.get("Kiteconfig", "kite_access_token"))
    mongo_port = (config_obj.get("mongo_details", "MongoPort"))
    mongo_db = (config_obj.get("mongo_details", "Database_name"))
    daily_data = (config_obj.get("mongo_details", "Daily_datastore"))
    nse_url = str(config_obj.get("URLS", "url"))
    nse_dump = str(config_obj.get("mongo_details", "NSE_datadump"))
    mongo_db_connect = str(config_obj.get("mongo_details", "Database_name"))
    Intraday_Selection = str(config_obj.get("mongo_details", "Intraday_Selection"))
    weekly_collection = (config_obj.get("mongo_details", "weekly_data_collection"))
#     Pivot_data

except Exception as e:
    raise Exception("Config file error: " + str(e))
# ------------------Authentication--------------

client = pymongo.MongoClient("localhost", 27017)
# kite = KiteConnect(api_key=key)
# kite.set_access_token(access_token)

# ----DataLoader--------------------------
# -----------
db = client[mongo_db_connect]
nse_coll=db[nse_dump]
weekly_coll=db[weekly_collection]

symbols_list=nse_coll.find({},{"Symbol":1,"Company Name":1,"_id":False})
symbols_list=list(symbols_list)
symbol_list_nse=[i["Symbol"] for i in symbols_list]

def get_week_change(ticker):
    response = {"Name": ticker}
    weekly_data = list(weekly_coll.find({"Name": ticker}, {"_id": False}))
    weekly_data = pd.DataFrame(weekly_data)
    if len(weekly_data)==0:
        return response
    weekly_data=weekly_data.tail(20)
    close_list=weekly_data['close'].tolist()
    date_list = weekly_data['date'].tolist()
    length=len(close_list)-1
    for i in range(len(close_list)-1):
        response["week_"+str(length)+"_change"]=round((close_list[i+1]-close_list[i])/close_list[i],2)
        response["week_" + str(length) + "_date"] = date_list[i+1]
        length-=1
    # response["week_9_change"]=  (close_list[1]- close_list[0])/close_list[0]
    # response["week_8_change"] = (close_list[2] - close_list[1])/close_list[1]
    # response["week_7_change"] = (close_list[3] - close_list[2])/close_list[2]
    # response["week_6_change"] = (close_list[4] - close_list[3])/close_list[3]
    # response["week_5_change"] = (close_list[5] - close_list[4])/close_list[4]
    # response["week_4_change"] = (close_list[6] - close_list[5])/close_list[5]
    # response["week_3_change"] = (close_list[7] - close_list[8])/close_list[8]
    # response["week_2_change"] = (close_list[9] - close_list[8])/close_list[8]
    # response["week_1_change"] = (close_list[10] - close_list[9])/close_list[9]
    return response



def intraday_index_fetch(nse_list):
    index_df = pd.DataFrame()
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        results = executor.map(get_week_change,nse_list)
    selected_index = index_df.append(list(results), ignore_index=True)
    selected_index.to_csv(r"C:\Users\stappdev\Desktop\stock_analysis-master\src\comparison\weekchange.csv", index=False)


intraday_index_fetch(symbol_list_nse)