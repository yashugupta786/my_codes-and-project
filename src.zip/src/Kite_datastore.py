from kiteconnect import KiteTicker, KiteConnect
import pandas as pd
import pytz
import concurrent.futures
import io
import requests
import os.path as path
import configparser
import pymongo
import datetime as dt
# import os
# os.chdir("C:/Users/stappdev/Desktop/stock_analysis-master")
# print("Current Working Directory " , os.getcwd())
from Price_action_techniques.config import sector_indices

CONFIG_DIR = path.abspath(path.join(__file__, "../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
try:
    config_obj.read(config_file_loc)
    key = str(config_obj.get("Kiteconfig", "kite_api_key"))
    access_token = str(config_obj.get("Kiteconfig", "kite_access_token"))
    mongo_port = (config_obj.get("mongo_details", "MongoPort"))
    mongo_db = (config_obj.get("mongo_details", "Database_name"))
    daily_data = (config_obj.get("mongo_details", "Daily_datastore"))
    nse_url = str(config_obj.get("URLS", "url"))
    last_Run=str(config_obj.get("mongo_details", "Last_Run"))
except Exception as e:
    raise Exception("Config file error: " + str(e))
# ------------------Authentication--------------
client = pymongo.MongoClient("localhost", 27017)
kite = KiteConnect(api_key=key)
kite.set_access_token(access_token)

# ----DataLoader-------------------------------------
db = client[mongo_db]
instrument_dump = kite.instruments("NSE")
# bse_instrument_dump = kite.instruments("BSE")

instrument_df = pd.DataFrame(instrument_dump)
# bse_instrument_df=pd.DataFrame(bse_instrument_dump)
nfo_instrument_dump = kite.instruments("NFO")
nfo_instrument_df = pd.DataFrame(nfo_instrument_dump)
IST = pytz.timezone('Asia/Kolkata')


class Data_storage(object):
    def __init__(self, days, intervals, nse_url,exchange):
        self.days = days
        self.interval = intervals
        self.url = nse_url
        self.sectr_list=sector_indices
        self.exchange=exchange

    def get_nse_data(self, url):

        # data = requests.get(url)
        # print(data.status_code)
        # url_content = data.content
        # data = data.content.decode('utf8')
        nifty_df = pd.read_csv(r"C:\Users\Deepam22\Desktop\stock_project\4_10_21_backup\stock_analysis-master\src\updated_nse_data.csv")
        nifty_df = nifty_df[nifty_df[" SERIES"].str.contains('EQ')]
        nifty_df.rename(columns={'NAME OF COMPANY': 'Company Name', 'SYMBOL': "Symbol"}, inplace=True)
        return nifty_df
    def utc_to_time(self,time, timezone='Asia/Kolkata'):
        return time.replace(tzinfo=pytz.utc).astimezone(pytz.timezone(timezone))

    def instrumentLookup(self, instrument_df, symbol):
        """Looks up instrument token for a given script from instrument dump"""
        try:
            return instrument_df[instrument_df.tradingsymbol == symbol].instrument_token.values[0]
        except:
            return -1

    def get_Kitedata(self, ticker):
        if self.exchange=="NSE":
            instrument = self.instrumentLookup(instrument_df, ticker)
        elif self.exchange=="NFO":
            instrument = self.instrumentLookup(nfo_instrument_df, ticker)

        if instrument == -1:
            return pd.DataFrame()
        # date_now=dt.datetime.strptime("Jan 28 2022", '%b %d %Y').date()
        date_now=dt.date.today()
        data = pd.DataFrame(
            kite.historical_data(instrument, date_now - dt.timedelta(self.days), date_now, self.interval))
        data['Name'] = ticker
        # data.drop(data.tail(1).index,inplace=True)
        if self.exchange == "NSE":
            data['date'] = data['date'].apply(self.utc_to_time)

        return data


    def schedule_job(self, symbollist):
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            results = executor.map(self.get_Kitedata, symbollist)
        return results

    def get_week_candle(self, week_df):
        close_data = week_df["close"].iloc[-1]
        date_extract = week_df['date'].iloc[0]
        low_value = week_df["low"].min()
        high_val = week_df["high"].max()
        open_val = week_df["open"].iloc[0]
        stock_name = week_df["Name"].iloc[0]
        return stock_name, close_data, date_extract, low_value, open_val, high_val
    def weekly_analysis2(self, df):
        week_col = db["WeeklyStockData"]
        df = df.copy()
        df['week_number'] = df['date'].dt.week.astype(str) + "-" + df['date'].dt.year.astype(str)
        df["DayName"] = df["date"].dt.day_name()
        weekly_analysis_df = pd.DataFrame(columns=["date", "Name", "close", "low", "open", "high", "week_number"])
        for item in set(df['Name'].tolist()):
            df1 = df[df['Name'] == item]
            if len(df1) < 1:
                continue
            gp_data = df1.groupby("week_number", sort=False)
            for name in gp_data.groups:
                prev_data=pd.DataFrame(list(week_col.find({"Name":item, "week_number": name}, {'_id': False})))
                group = gp_data.get_group(name)
                group=pd.concat([prev_data,group])
                # group.sort_values(by='date')

                stock_name, close_data, date_extract, low_value, open_val, high_val = self.get_week_candle(group)
                df2 = pd.DataFrame({"date": [date_extract],
                                    "Name": [stock_name],
                                    "close": [close_data],
                                    "low": [low_value],
                                    "open": [open_val],
                                    "high": [high_val],
                                    "week_number": [name],
                                    })
                weekly_analysis_df = weekly_analysis_df.append(df2, ignore_index=True)
        return weekly_analysis_df

    def weekly_analysis(self, df):

        df=df.copy()
        df['week_number'] = df['date'].dt.week.astype(str) +"-"+ df['date'].dt.year.astype(str)
        df["DayName"] = df["date"].dt.day_name()
        weekly_analysis_df = pd.DataFrame(columns=["date", "Name", "close", "low", "open", "high", "week_number"])

        for item in set(df['Name'].tolist()):
            df1 = df[df['Name'] == item]
            if len(df1) < 1:
                continue
            gp_data = df1.groupby("week_number", sort=False)
            for name in gp_data.groups:
                group = gp_data.get_group(name)
                stock_name, close_data, date_extract, low_value, open_val, high_val = self.get_week_candle(group)
                df2 = pd.DataFrame({"date": [date_extract],
                                    "Name": [stock_name],
                                    "close": [close_data],
                                    "low": [low_value],
                                    "open": [open_val],
                                    "high": [high_val],
                                    "week_number": [name],
                                    })
                weekly_analysis_df = weekly_analysis_df.append(df2, ignore_index=True)

        return weekly_analysis_df

    def store_kite_data(self, time_frame):
        if self.exchange == "NSE":
            col1 = db[time_frame + "stock_data"]
            # col1.remove()
            col2 = db["WeeklyStockData"]
            # col2.remove()
            col3=db["NSE_Data"]
            col3.remove()
            #
            col4=db["sector_data"]
            # col4.remove()

            Finaldf = pd.DataFrame()
            sectr_df = pd.DataFrame()
            stock_df = self.get_nse_data(nse_url)
            symbollist = stock_df['Symbol'].tolist()

            # symbollist=['HDFCBANK']
            results = self.schedule_job(symbollist)
            # self.days=4
            # sectr_df_res=self.schedule_job(self.sectr_list)
            dailydf = pd.DataFrame.append(Finaldf, list(results), ignore_index=True)
            # sectr_res = pd.DataFrame.append(sectr_df, list(sectr_df_res), ignore_index=True)
            # sve_sectr_data = sectr_res.T.to_dict().values()
            # col4.insert_many(sve_sectr_data)
            df_weekly = self.weekly_analysis2(dailydf)
            final_daily_df=pd.DataFrame()
            for i in symbollist:
                final_daily_df=pd.DataFrame.append(final_daily_df, dailydf[dailydf["Name"]==i].tail(120), ignore_index=True)
                final_daily_df.drop(final_daily_df.tail(1).index, inplace=True)
            # dailydf=dailydf
            dailyjson_data = final_daily_df.T.to_dict().values()
            col1.insert_many(dailyjson_data)
            weekly_json = df_weekly.T.to_dict().values()
            col2.insert_many(weekly_json)
            nse_Data = stock_df.T.to_dict().values()
            col3.insert_many(nse_Data)
        elif self.exchange == "NFO":
            col5 = db["nfo_data"]
            col5.remove()
            nfo_df = pd.DataFrame()
            nfo_list=nfo_instrument_df['tradingsymbol'].tolist()
            results_nfo = self.schedule_job(nfo_list)
            nfo_df = pd.DataFrame.append(nfo_df, list(results_nfo), ignore_index=True)
            dailynfo_data = nfo_df.T.to_dict().values()
            col5.insert_many(dailynfo_data)
today=dt.date.today()
from datetime import datetime

last_run_date = datetime.strptime(last_Run, '%b %d %Y').date()
delta=today-last_run_date
obj1 = Data_storage(delta.days, "day", nse_url,"NSE")
obj1.store_kite_data("day")
config_obj["mongo_details"]["Last_Run"]=today.strftime('%b %d %Y')
with open(CONFIG_DIR + "/config/Config.cfg", 'w') as configfile:
    config_obj.write(configfile)
# obj2 = Data_storage(10, "day", None,"NFO")
# obj2.store_kite_data("day")
