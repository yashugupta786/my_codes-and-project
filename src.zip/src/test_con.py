import requests

requests.get("https://www1.nseindia.com/content/equities/EQUITY_L.csv")
