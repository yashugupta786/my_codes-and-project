import time

from kiteconnect import KiteTicker, KiteConnect
import pandas as pd
import pytz
import concurrent.futures
import io
import requests
import os.path as path
import configparser
import pymongo
import datetime as dt
from src.Price_action_techniques.config import sector_indices
from src.Price_action_techniques.config import *
from src.Price_action_techniques.Indicators import *
from src.Price_action_techniques.vwap_rsi_pivot_stategy import *
CONFIG_DIR = path.abspath(path.join(__file__, "../../"))
config_file_loc = CONFIG_DIR + "/config/Config.cfg"
config_obj = configparser.ConfigParser()
import re
try:
    config_obj.read(config_file_loc)
    key = str(config_obj.get("Kiteconfig", "kite_api_key"))
    access_token = str(config_obj.get("Kiteconfig", "kite_access_token"))
    mongo_port = (config_obj.get("mongo_details", "MongoPort"))
    mongo_db = (config_obj.get("mongo_details", "Database_name"))
    daily_data = (config_obj.get("mongo_details", "Daily_datastore"))
    # daily_collection = (config_obj.get("mongo_details", "Daily_datastore"))
    nse_url = str(config_obj.get("URLS", "url"))
    nse_dump = str(config_obj.get("mongo_details", "NSE_datadump"))
    mongo_db_connect = str(config_obj.get("mongo_details", "Database_name"))
    Swing_Selection = str(config_obj.get("mongo_details", "Swing_Selection"))
    Intraday_Selection = str(config_obj.get("mongo_details", "Intraday_Selection"))
#     Pivot_data

except Exception as e:
    raise Exception("Config file error: " + str(e))
# ------------------Authentication--------------

client = pymongo.MongoClient("localhost", 27017)
kite = KiteConnect(api_key=key)
kite.set_access_token(access_token)

# ----DataLoader--------------------------
# -----------
db = client[mongo_db_connect]
nse_coll=db[nse_dump]
Intraday_Selection_col=db[Intraday_Selection]
Swing_Selection_col=db[Swing_Selection]
symbols_list=Swing_Selection_col.find( { "Buying Analysis": { "$not": re.compile("Skip|Sell") } } ,{"Name":1,"Company name":1,"_id":False})
symbols_list=list(symbols_list)
symbol_list_nse=[i["Name"] for i in symbols_list]
company_name=[i["Company name"] for i in symbols_list]
stock_info=dict(zip(symbol_list_nse,company_name))
# symbol_list_nse=["DNAMEDIA"]

class Intraday_techniques(object):

    def __init__(self,days, intervals):
        self.all_nse = symbol_list_nse
        self.sector_index=sector_indices
        self.days = days
        self.interval = intervals

    def get_index_change(self,ticker):
        final_result = {}
        stock_index = get_Kitedata(ticker, 1, "day", kite)
        current_close = stock_index['close'].tolist()[-1]
        prev_1d_close = stock_index['close'].tolist()[-2]
        change_1 = current_close - prev_1d_close
        change_1per = [round(change_1 / prev_1d_close * 100, 2)]
        stock_index=stock_index.tail(-1)
        stock_index.drop(['volume'], axis = 1,inplace=True)
        stock_index["%percentage_change"]=change_1per
        print(stock_index)
        return stock_index

    def getstocks_data(self,ticker):
        print(ticker)
        final_res={}
        final_res['Symbol']=ticker
        stock_df = get_Kitedata(ticker, 3, "5minute", kite)
        # stock_df.drop(stock_df.tail(61))
        # stock_df=stock_df[:-60]
        if len(stock_df) == 0:
            return final_res

        final_res.update(intra_strategy(ticker, stock_df))
        # print(stock_df)
        return final_res


    def schedule_job_stocks(self):
        res_df=pd.DataFrame()
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            results = executor.map(self.getstocks_data, self.all_nse)
        res_df = res_df.append(list(results), ignore_index=True)
        return res_df

    def intraday_index_fetch(self):
        index_df= pd.DataFrame()
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            results = executor.map(self.get_index_change, self.sector_index)
        selected_index= index_df.append(list(results), ignore_index=True)
        selected_index.to_csv(r"C:\Users\stappdev\Desktop\stock_analysis-master\src\Results\Indexchange.csv",index=False)

    def intraday_stock_data(self):
        results=self.schedule_job_stocks()
        # print(results)
        return results

daily_coll = db[daily_data]
for ticker in symbol_list_nse:
    daily_data=list(daily_coll.find({"Name":ticker},{"_id":False}))
    daily_data = pd.DataFrame(daily_data)
    print(ticker)
    result=get_pivots(daily_data.tail(1))
    result['Name']=ticker
    Pivot_col.update({'Name':ticker},{ "$set": result }, upsert=True )
from datetime import datetime
while (True):
    obj1= Intraday_techniques(1, "day")
    # obj1.intraday_index_fetch()
    selected_stock=obj1.intraday_stock_data()
    time_stamp=datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")

    selected_stock.to_csv(r'Results/intraday/intra_stocks'+time_stamp+'.csv',index=False)
    selected_stock_data=selected_stock.T.to_dict().values()
    Intraday_Selection_col.remove()
    Intraday_Selection_col.insert_many(selected_stock_data)
    time.sleep(290)