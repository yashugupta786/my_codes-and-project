import pandas as pd
from sklearn .preprocessing import Imputer
my_data=pd.read_csv("housing.csv")
# print(my_data.head())
# print(my_data.info())
# print(my_data["ocean_proximity"].value_counts())
# print(my_data.describe())
imputer=Imputer(strategy="median")
housing=my_data.drop("ocean_proximity",axis=1)
# print(housing.head())
imputer.fit(housing)
imputer.statistics_
housing.median().values
X=imputer.transform(housing)
yoyo=pd.DataFrame(X,columns=housing.columns)
# print(yoyo.head())
# print(yoyo.info())
from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()
cat=my_data["ocean_proximity"]
encoded_ocean=lb.fit_transform(cat)
print(encoded_ocean)
