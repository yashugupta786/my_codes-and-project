import MySQLdb as db
import pandas as pd
db = db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="breastcancer"
                )
Cursor = db.cursor()
Cursor.execute("SELECT clump_thickness,unif_cell_size,unif_cell_shape,marg_adhesion,single_epith_cell_size,"
               "bare_nuclei,bland_chrom,norm_nucleoli,mitoses,class1 FROM breast_cancer")
row=Cursor.fetchall()
clump_thickness=[]
while row is not None:
    clump_thickness.append(row[1][0])

print(clump_thickness)





