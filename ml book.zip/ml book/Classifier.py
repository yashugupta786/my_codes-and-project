# --------------------------------------------------------------------#
# This class has functions related model training and storage  and
# fetching interpreted questions
# class from different sources
# Author : Mayank Vashishtha
# Email : mayank.vashishtha@genpact.digital
# -------------------------------------------------------------------#

import csv
import operator
from sklearn import preprocessing
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import SGDClassifier
import numpy as np
from sklearn import neighbors
import sqlite3
from utils import Utils
from sklearn.naive_bayes import MultinomialNB

from config import server_settings
from utils import QueryProcessor as QueryProcessor
import mysql.connector
import re
import logging


logger = logging.getLogger("Classifier")
logger.setLevel(logging.INFO)

handler = logging.StreamHandler()
handler.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

logger.addHandler(handler)


class Classifier:
    def __init__(self):
        self.x = []
        self.y = []
        self.type = server_settings.CLASSIFIER_TYPE
        self.question_cls_dict = {}
        self.q_qid_dict={}
        self.q_treeid_dict={}
        self.q_intent_dict={}
        self.q_command_dict = {}

    # ------------------------------------------------
    # this functions trains a model on csv data
    # @returns a model pipeline and a label encorder
    # ------------------------------------------------

    def train(self, db, seed, training):
        self.read_train_data_db(db, seed, training)
        logger.info("The X Train length : %d  The Y Train %d",len(self.x),len(self.y))
        le = preprocessing.LabelEncoder()
        le.fit(self.y)
        logger.info("Available classes %s",list(le.classes_))
        Y_full = le.transform(self.y)
        X_full = self.x

        if (self.type == 'KN'):
            logger.info("Building model with K Nearest Neighbour approximation")
            text_clf = Pipeline([('vect', CountVectorizer(ngram_range=(1,2), token_pattern=r'\b\w+\b', min_df=0,
                                                          stop_words='english', analyzer='word')),
                                 ('tfidf', TfidfTransformer()),
                                 ('clf', neighbors.KNeighborsClassifier(n_neighbors=4)), ])
        elif (self.type == 'SGD'):
            logger.info("Building model with SGD approximation")
            text_clf = Pipeline([('vect', CountVectorizer(ngram_range=(1, 2), token_pattern=r'\b\w+\b', min_df=0,
                                                          stop_words='english', analyzer='word')),
                                 ('tfidf', TfidfTransformer()), ('clf',
                                                                 SGDClassifier(loss='log', penalty='l2', alpha=1e-3,
                                                                               n_iter=5, random_state=42,
                                                                             shuffle=True)), ])
        elif(self.type=='MNB'):
            logger.info("Building model with MNB approximation")
            text_clf = Pipeline([('vect', CountVectorizer(ngram_range=(1,2), token_pattern=r'\b\w+\b', min_df=0,
                                                          stop_words='english', analyzer='word')),
                                 ('clf', MultinomialNB(alpha=1.0, class_prior=None, fit_prior=True)), ])

        text_clf = text_clf.fit(X_full, Y_full);
        logger.info("model built")
        return text_clf, le, self.question_cls_dict,self.q_qid_dict,self.q_treeid_dict,self.q_intent_dict,self.q_command_dict

    # ------------------------------------------------
    # this functions predicts the interpreted question for a given query
    # @input a model and a label encorder for the model
    # @returns a interpreted query class
    # ------------------------------------------------

    def fetch_interpreted_q(self, text_clf, le, query):
        otherq = []
        scores = []
        pred = text_clf.predict(query)
        # print math.exp(text_clf.decision_function(query)[0][pred[0]])
        # print text_clf.intercept_
        # print text_clf
        otherpreds = text_clf.predict_proba(query)[0]
        print np.sum(otherpreds)
        maximum = otherpreds[pred[0]]
        # print text_clf.steps[2][1].intercept_
        #otherpreds = np.delete(otherpreds, pred)
        otherpreds[pred[0]]=-1
        logger.info("The Maximum Confidence Answer is %f"%maximum);
        i = 0
        limit = 3
        if (len(otherpreds) < 3):
            limit = len(otherpreds)
        while i < limit:
            max_score = np.argmax(otherpreds)
            otherq.append(max_score)
            scores.append(otherpreds[max_score])
            otherpreds[max_score]=-1
            #otherpreds[max_score]=0.0000
            i += 1
        logger.info("The Other top scores are ")
        logger.info(scores)
        other_int_q = le.inverse_transform(np.array(otherq))
        inter_q = le.inverse_transform(pred)

        return inter_q, other_int_q, scores, maximum

    def store_new_train(self, text, label, path):
        try:
            fn = open(path, 'a')
            line = text + ',' + label
            fn.write(line + '\n')
        except ValueError:
            pass
        finally:
            fn.close()

    def read_train_data(self, path):
        try:
            f = open(path, 'rt')
            reader = csv.reader(f)
            for row in reader:
                self.x.append(Utils.remove_non_ascii(row[1]))
                # self.x.append(Utils.remove_non_ascii(row[6]))
                self.y.append(Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", "")))
                self.question_cls_dict[
                    Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = Utils.remove_non_ascii(row[2])
                self.q_qid_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[0]
                self.q_treeid_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[3]
                self.q_intent_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[4]
                self.q_command_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[5]


        finally:
            f.close()

    def read_train_data_db(self, db, seed, training):
        conn =  mysql.connector.connect(user=server_settings.MYSQL_USER, password=server_settings.MYSQL_USER,host=server_settings.MYSQL_HOST,database=db)
        c = conn.cursor()
        obj_processor = QueryProcessor.QueryProcessor()
        dictionary_data = obj_processor.get_all_dict_data()
        try:
            rs = c.execute(
                           '''select ''' + training + '''.qid,''' + training + '''.new_question,''' + seed + '''.interpretation,''' +seed+'''.decisionTreeID,'''+seed+'''.intent,'''+seed+'''.commandFlag,''' + seed + '''.answer  from ''' + training + ''' inner join ''' + seed + ''' on ''' + training + '''.qid=''' + seed + '''.qid WHERE '''+seed+'''.active=1''')
            for row in c:
                new_question = row[1]
                new_interpretation = row[2]
                for key,values in dictionary_data.iteritems():
                    for value in values:
                        if value in new_question:
                            #print new_question
                            new_question = re.sub(r'\b%s\b' %value,key,new_question)
                            break
                        else:
                            new_question = new_question

                        if value in new_interpretation:
                            new_interpretation = re.sub(r'\b%s\b' % value, key, new_question)
                            break
                        else:
                            new_interpretation = new_interpretation

                self.x.append(Utils.remove_non_ascii(new_question))
                #self.x.append(Utils.remove_non_ascii(row[6]))
                self.y.append(Utils.remove_non_ascii(new_interpretation.replace(" ", "_").replace("?", "")))
                self.question_cls_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = Utils.remove_non_ascii(row[2])
                self.q_qid_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[0]
                self.q_treeid_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[3]
                self.q_intent_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))]=row[4]
                self.q_command_dict[Utils.remove_non_ascii(row[2].replace(" ", "_").replace("?", ""))] = row[5]

            for key in self.question_cls_dict:
                self.x.append(self.question_cls_dict[key])
                self.y.append(key)

        except:
            pass
        finally:
            #conn.commit()
            conn.close()

    def clear_model(self):
        self.x = []
        self.y = []
        self.question_cls_dict = {}

    def save_model(self, model, labeler):
        return

    def read_model(self):
        return


    def common_method(self,csvpath,query):
        logger.info("Inside Common Method")
        # self.read_train_data(csvpath)
        other_questions = []
        global labler
        global question_dict
        global qid_dict
        global treeid_Dict
        global answers
        global intent_dict
        global command_dict
        model, labler, question_dict, qid_dict, treeid_Dict, intent_dict, command_dict = self.train('gnip','seed','training')
        interpreted_question, other_interperted_questions, scores, max_score = self.fetch_interpreted_q(model,labler,query)
        print "interpreted_question ----- %s"%question_dict[interpreted_question[0]]
        for each_question in other_interperted_questions:
            other_question = question_dict[each_question]
            other_questions.append(other_question)
        print "other_interperted_questions %s"%other_questions




if __name__ == "__main__":

    obj = Classifier()
    csvpath = "seed_data.csv"
    question = "Personal Identification Number"
    query = []
    query.append(question)
    response = obj.common_method(csvpath,query)
    print response
