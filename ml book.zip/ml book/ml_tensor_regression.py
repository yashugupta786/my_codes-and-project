from sklearn.datasets import fetch_california_housing

import numpy as np
housing=fetch_california_housing()
# print(housing)
m,n= housing.data.shape
# print(m)
# print(n)
housing_data_plus_bias=np.c_[np.ones((m,1)),housing.data]
print(housing_data_plus_bias)