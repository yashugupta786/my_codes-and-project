import sqlalchemy
from sqlalchemy import Column,Table,ForeignKey,INTEGER,String
from sqlalchemy import create_engine
from sqlalchemy import MetaData,Table,insert,update,delete
engine = create_engine('mysql://root:root@localhost/appen_proj')
print(engine.table_names())
meta_data=MetaData()
data_rec=Table('appen_db_table',meta_data,autoload=True,autoload_with=engine)
print(repr(data_rec))
print("----------------------------")
ins=data_rec.insert()
new_user=ins.values(qid=6,queries="how do i change my password")
conn=engine.connect()
conn.execute(new_user)