import MySQLdb as my_db
db = my_db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="appen_proj"
                )
output=[]
Cursor = db.cursor()
# Cursor.execute("SELECT qid, queries FROM appen_db_table WHERE qid=%s" %(qid))
Cursor.execute("SELECT qid, queries FROM appen_db_table")
row = Cursor.fetchone()
while row is not None:
    # print (row[1])
    output.append(row[1])
    row = Cursor.fetchone()

print(output)

Cursor.close()

db.close()
