import pandas as pd
import MySQLdb as my_db
df=pd.read_csv("data_auto.csv",encoding='latin-1',names = ['qid','queries'])
list1=df.queries.tolist()
list2=df.qid.tolist()

db = my_db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="appen_proj"
                )
Cursor = db.cursor()
'''
for inserting data in the DATABASE 
'''
# for i,row in enumerate(list2):
#     # v="INSERT INTO appen_db_table(qid,queries) VALUES(%s,\"%s\")" % (row,list1[i])
#     # print(v)
#     Cursor.execute("INSERT INTO appen_db_table(qid,queries) VALUES(%s,\"%s\")" % (row,list1[i]))
db.commit()
db.close()

