students = [("Alejandro", ["CompSci", "Physics"]),
            ("Justin", ["Math", "CompSci", "Stats"]),
            ("Ed", ["CompSci", "Accounting", "Economics"]),
            ("Margot", ["InfSys", "Accounting", "Economics", "CommLaw"]),
            ("Peter", ["Sociology", "Economics", "Law", "Stats", "Music"])]
# for data ,subjects in students:
#     print(data +" takes " + str(len(subjects)) + " subjects" )
#
counter=0
for boggu in students:

    for s in boggu[1]:
        if s =="CompSci":
            print(boggu[0] + " takes " + s)
            counter +=1





    print("student " + boggu[0] + " takes " + str(len(boggu[1])) + " subjects")

