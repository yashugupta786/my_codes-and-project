import MySQLdb as my_db

db = my_db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="appen_proj"
                )
cursor = db.cursor()
sql = "insert into appen_db_table VALUES(7,'how do i change my password')"
number_of_rows = cursor.execute(sql)
db.commit()  # you need to call commit() method to save
# your changes to the database
db.close()