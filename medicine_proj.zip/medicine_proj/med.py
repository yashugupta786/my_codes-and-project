import MySQLdb as db
import pandas as pd
db = db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="pharmacy"
                )
Cursor = db.cursor()
train=pd.read_csv("med.csv")
# print(train.head())

# print(new_Data)
# id=train["id"].tolist()
# medicine_name=train["medicine_name"].tolist()
# category=train["category"].tolist()
# price=train["price"].tolist()
# # new_price=list(map(str,price))
#
#
# # for i ,j in enumerate(id):
# #
# #     v=Cursor.execute("""INSERT INTO all_info_medicine VALUES (%s,%s,%s,%s)""",(j,medicine_name[i],category[i],price[i]))
# #     print(v)
#
Cursor.execute("SELECT medicine_name, price,id FROM all_info_medicine")
row=Cursor.fetchall()

def results():
    all_new=[]
    dict1={}
    for i in row:
        # print(i)

        dict1[str(i[2])]={}
        dict1[str(i[2])][str(i[0])]=str(i[1])
        # print(dict1)

    return dict1

import json
all_results=results()
new_data1=json.dumps(all_results)
print(new_data1)
db.commit()
db.close()