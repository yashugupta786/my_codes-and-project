import MySQLdb as db
import pandas as pd
db = db.connect(host="127.0.0.1",
                user="root",
                passwd="root",
                db="pharmacy"
                )
Cursor = db.cursor()