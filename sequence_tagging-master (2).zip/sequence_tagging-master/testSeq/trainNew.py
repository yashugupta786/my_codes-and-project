

#Step 1
# shared global variables to be imported from model also


import numpy as np
import ConfigPara as config
from ReadDatasets import get_processing_word, ReadData
from NerTrain import TensorTrain


trainObj=TensorTrain()
processing_word = get_processing_word(lowercase=True)
# Generators

dev   = ReadData(config.filename_dev, processing_word)
test  = ReadData(config.filename_test, processing_word)
train = ReadData(config.filename_train, processing_word)

datasets=[train,test,dev]

#Step2
# Build Vocab
print("Building vocab...")
vocab_words = set()
vocab_tags = set()
for dataset in datasets:
    for words, tags in dataset:
        vocab_words.update(words)
        vocab_tags.update(tags)
print("- done. {} tokens".format(len(vocab_words)))


# Read Glove vec
print("Building vocab...")
Glovevocab = set()
with open(config.Glovefilename, encoding="utf8") as f:
    for line in f:
        word = line.strip().split(' ')[0]
        Glovevocab.add(word)

#get Common Vocab from glove and given dataset
vocab = vocab_words & Glovevocab
vocab.add(config.UNK)
vocab.add(config.NUM)
Vocab_dic = dict()
Tag_dic=dict()
for idx, word in enumerate(vocab):
    word = word.strip()
    Vocab_dic[word] = idx


for Tagidx, tagword in enumerate(vocab_tags):
    tagword = tagword.strip()
    Tag_dic[tagword] = Tagidx

# Generate Common Embeddings
embeddings = np.zeros([len(Vocab_dic), config.dim_word])
with open(config.Glovefilename, encoding="utf8") as f:
    for line in f:
        line = line.strip().split(' ')
        word = line[0]
        embedding = [float(x) for x in line[1:]]
        if word in Vocab_dic:
            word_idx = Vocab_dic[word]
            embeddings[word_idx] = np.asarray(embedding)


#Read Training Data
train = ReadData(config.filename_train)



####-------------- Start Training ----------------#####

print(" process for training started")
nwords     = len(Vocab_dic)
ntags      = len(Tag_dic)



idx_to_tag = {idx: tag for tag, idx in Tag_dic.items()}
processing_tag  = get_processing_word(Tag_dic,
                lowercase=True, allow_unk=True)
trainObj.add_placeholders()
print(" placeholders Intialized")
trainObj.add_word_embeddings_op(embeddings,nwords)
print(" words embedding Intialized")
trainObj.add_logits_op(ntags)
print(" logiopts")
trainObj.add_pred_op()
print(" add_pred_op")
trainObj.add_loss_op()
print(" add_loss_op")
trainObj.add_train_op(config.lr_method, config.lr,
                config.clip)

print(" add_train_op")
trainObj.initialize_session()
print(" initialize_session")
processing_word=get_processing_word(Vocab_dic, lowercase=True)
processing_tag=get_processing_word(Tag_dic,lowercase=True)
dev = ReadData(config.filename_dev, processing_word,
                   processing_tag, config.max_iter)
print(" dev ReadData")
train = ReadData(config.filename_train, processing_word,
                     processing_tag, config.max_iter)

print(" train ReadData")
# train model
trainObj.train(train, dev)

print(" train")
print("done")


