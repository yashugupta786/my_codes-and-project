UNK = "$UNK$"
NUM = "$NUM$"
NONE = "O"
dim_word = 300

filename_train = "../data2/trainData.txt"
filename_dev = "../data2/devData.txt"
filename_test = "../data2/testData.txt"
Glovefilename="../data2/glove/glove.6B.300d.txt"

# model hyperparameters
hidden_size_char = 100  # lstm on chars
hidden_size_lstm = 300  # lstm on word embeddings


use_crf=True
train_embeddings = False
nepochs = 15
dropout = 0.5
batch_size = 20
lr_method = "adam"
lr = 0.01
lr_decay = 0.9
clip = -1  # if negative, no clipping
nepoch_no_imprv = 3
max_iter = None
dir_output="testModel/"

