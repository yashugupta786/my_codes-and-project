import nltk


a=[('i', 'O'), ('am', 'O'), ('java', 'B-ROLE'), ('developer,', 'I-ROLE'), ('data', 'B-SKILL'), ('science,', 'I-SKILL'), ('java', 'B-SKILL'), ('looking', 'O'), ('for', 'O'), ('change', 'O'), ('in', 'O'), ('nlp', 'B-SKILL')]
b='i am java developer data science, java, looking for change in nlp'
zippedData = [i for i in a if i[1] !='O' ]
X='B-'
print(b)
print(zippedData)

rolegrammar = "role: {<B-ROLE><I-ROLE>*}"
skillgrammar = "Skill: {<B-SKILL><I-SKILL>*}"
role1 = nltk.RegexpParser(rolegrammar)
skill1=nltk.RegexpParser(skillgrammar)
roles=[]
skills=[]


#role1result = role1.parse(zippedData)
for s in skill1.parse(zippedData):
    if (type(s) is nltk.tree.Tree):
        skills.append(" ".join([i for i, j in (s)]))
print(skills)
print('----------------')
for r in role1.parse(zippedData):
    if (type(r) is nltk.tree.Tree):
        #print(j)
        roles.append(" ".join([i for i,j in (r)]))
print(roles)