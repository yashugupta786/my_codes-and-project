

data=[]
filename="testdata.txt"
with open(filename,encoding='UTF-8') as f:
    Filedata=f.readlines()

print(len(Filedata))
import csv



import requests
import json,ast
headers = {'content-type': 'application/json'}



for i,x in enumerate(Filedata):
    print(i)
    crfUrl="http://10.216.204.220:8090/extractentity/fetchEntity"
    Crfresponse=requests.post(crfUrl, data=json.dumps(data), headers=headers)

    data = {"sentence": str(x)}
    RnnUrl='http://10.216.204.220:9999/getRnnNerEntites'
    RnnResponse=requests.post(RnnUrl, data=json.dumps(data), headers=headers)
    CrfjsonData = json.loads(Crfresponse.text)
    RnnData = (ast.literal_eval(RnnResponse.text)['DATA'])
    if 'roleList'  not in CrfjsonData:
        CrfjsonData['roleList']=[]
    if  'skillList'  not in CrfjsonData:
        CrfjsonData['skillList']=[]
    with open('output.csv', 'a',encoding='UTF-8') as csvFile:
        writer = csv.writer(csvFile)
        CSVDATA = [x, RnnData['B-ROLE'], CrfjsonData['roleList'], RnnData['B-SKILL'], CrfjsonData['skillList'], '',
               RnnData['B-LOCATION'], RnnData['B-SUFFIX'], RnnData['B-ORGS']]
        writer.writerow(CSVDATA)
