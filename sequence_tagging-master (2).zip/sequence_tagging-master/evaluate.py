from model.data_utils import CoNLLDataset
from model.ner_model import NERModel
from model.config import Config
import nltk


def align_data(data):
    """Given dict with lists, creates aligned strings

    Adapted from Assignment 3 of CS224N

    Args:
        data: (dict) data["x"] = ["I", "love", "you"]
              (dict) data["y"] = ["O", "O", "O"]

    Returns:
        data_aligned: (dict) data_align["x"] = "I love you"
                           data_align["y"] = "O O    O  "

    """
    spacings = [max([len(seq[i]) for seq in data.values()])
                for i in range(len(data[list(data.keys())[0]]))]
    data_aligned = dict()

    # for each entry, create aligned string
    for key, seq in data.items():
        str_aligned = ""
        for token, spacing in zip(seq, spacings):
            str_aligned += token + " " * (spacing - len(token) + 1)

        data_aligned[key] = str_aligned

    return data_aligned

nerTags={'B-LOCATION':'I-LOCATION','B-ROLE':'I-ROLE','O':'','B-SUFFIX':'','B-ORGS':'I-ORGS','B-SKILL':'I-SKILL'}

def genEntity(zippedData):
    zippedData = [i for i in zippedData if i[1] != 'O']
    #suffixesData = [i for i in zippedData if i[1] == 'B-SUFFIX']
    tagGrammer=""
    NerEntities={}
    for beginTag,endTag in (nerTags.items()):
       # "role: {<B-ROLE><I-ROLE>*}"
        tagGrammer=str(beginTag)+": {<"+beginTag+"><"+endTag+">*}"
        Entities=nltk.RegexpParser(tagGrammer)
        EntitiesList=[]
        for s in Entities.parse(zippedData):
            if (type(s) is nltk.tree.Tree):
                EntitiesList.append(" ".join([i for i, j in (s)]))
        #print(EntitiesList)
        NerEntities[beginTag]=EntitiesList
    return (NerEntities)
    #print("suffixesData: ",suffixesData)

def getEntities(zippedData):
    zippedData = [i for i in zippedData if i[1] != 'O']
    X = 'B-'
    #print(zippedData)

    rolegrammar = "role: {<B-ROLE><I-ROLE>*}"
    skillgrammar = "Skill: {<B-SKILL><I-SKILL>*}"
    role1 = nltk.RegexpParser(rolegrammar)
    skill1 = nltk.RegexpParser(skillgrammar)
    roles = []
    skills = []

    # role1result = role1.parse(zippedData)
    for s in skill1.parse(zippedData):
        if (type(s) is nltk.tree.Tree):
            skills.append(" ".join([i for i, j in (s)]))
    for r in role1.parse(zippedData):
        if (type(r) is nltk.tree.Tree):
            # print(j)
            roles.append(" ".join([i for i, j in (r)]))
    return skills,roles



        # else:
        #     print("no entity for w :",w)

def interactive_shell(model):
    """Creates interactive shell to play with model

    Args:
        model: instance of NERModel

    """
    model.logger.info("""
This is an interactive mode.
To exit, enter 'exit'.
You can enter a sentence like
input> I am a java developer in delhi""")

    while True:
        try:
            # for python 2
            sentence = raw_input("input> ")

        except NameError:
            # for python 3
            sentence = input("input> ")
        sentence=sentence.replace(","," , ")
        words_raw = sentence.strip().split(" ")

        if words_raw == ["exit"]:
            break

        preds = model.predict(words_raw)

        zippedData=list(zip(words_raw,preds))
        #skills,roles=getEntities(zippedData)
        #print( "Skills :",skills)
        #print("Roles :", roles)
        NerEntities=genEntity(zippedData)
        print(NerEntities)


def main():
    # create instance of config
    config = Config()

    # build model
    model = NERModel(config)
    model.build()
    model.restore_session(config.dir_model)

    # create dataset
    test  = CoNLLDataset(config.filename_test, config.processing_word,
                         config.processing_tag, config.max_iter)

    # evaluate and interact
    #model.evaluate(test)
    interactive_shell(model)

def loadmodel():
    config = Config()

    # build model
    model = NERModel(config)
    model.build()
    model.restore_session(config.dir_model)
    return model

def apiRequest(sentence,model):
    sentence = sentence.replace(",", " , ")
    words_raw = sentence.strip().split(" ")
    preds = model.predict(words_raw)
    zippedData = list(zip(words_raw, preds))
    # skills,roles=getEntities(zippedData)
    # print( "Skills :",skills)
    # print("Roles :", roles)
    NerEntities = genEntity(zippedData)
    return (NerEntities)


if __name__ == "__main__":
    main()
    #apiRequest("i am java developer")