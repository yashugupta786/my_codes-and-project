from imageTextExtractor import ImageTextExtractor
from PIL import Image
import datefinder
import re
import os
import json

upto_interested_block=20
CurrencyPettern=r'[^\d.\-\ \$]'

image_block_obj = ImageTextExtractor()
# file='Ahren Jetensky W2.JPG'
outputFilePath="../w2/format_images_diff"

inputFilePath="../w2/format_images_diff"
inpfile='0064O00000jmlA5QAI-00P4O00001KS41hUAD-Sheila Dirks Dynamic 2017 W2.pdf'
filename, file_extension = os.path.splitext(inpfile)

outputFilePath="../output/W2/"


def imgtoContent(path_img):
    print(path_img)
    contents_pdf = []
    for imagefiles in path_img:
        imagefiles = Image.open(imagefiles)
        text_seg = image_block_obj.process_image(imagefiles)

        # text_seg = [i for i in text_seg if i!='']
        # contents_pdf.extend(text_seg)
    return text_seg


def ExtractDataFromSegs(text_seg):
    Entities={}

    for eachline in text_seg:
        #dict entities
        for eachkey,eachvalue in DataToExtract.EntityData.items():
            if eachkey in eachline:
                Entities[eachkey]=eachvalue
                Entities[eachkey] = [x for x in re.sub(CurrencyPettern, '', eachline).split(" ") if len(x) > 0][0]

        #parse date
        DateSec = eachline.lower().replace("due", "D_Date").replace("notice", "N_Date")
        Datesmatches = list(datefinder.find_dates(DateSec))
        if len(Datesmatches) > 0 and 'D_Date' in DateSec:
            Entities["Capital_call_due_date"] = Datesmatches[0].date()
        elif len(Datesmatches) > 0 and 'N_Date' in DateSec:
            Entities["Capital_Call_notice_date"] = Datesmatches[0].date()

        #fund name
        if DataToExtract.Fund_Name in eachline:
            Entities['Fund_Name'] = DataToExtract.Fund_Name

    return Entities






contents_pdf=imgtoContent([inputFilePath+filename+file_extension])
#Entities=ExtractDataFromSegs(text_seg=contents_pdf)

print(contents_pdf)

with open(outputFilePath+filename+'.json', 'w', encoding='utf-8') as f:
    json.dump(contents_pdf, f, ensure_ascii=False, indent=4)
