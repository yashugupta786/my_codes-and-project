import PyPDF2

# creating a pdf file object
pdfFileObj = open('../w2/format_imges_diff/0064O00000jmlA5QAI-00P4O00001KS41hUAD-Sheila Dirks Dynamic 2017 W2.pdf', 'rb')

# creating a pdf reader object
pdfReader = PyPDF2.PdfFileReader(pdfFileObj)

# printing number of pages in pdf file
print(pdfReader.numPages)

# creating a page object
pageObj = pdfReader.getPage(0)

# extracting text from page
print(pageObj.extractText())

# closing the pdf file object
pdfFileObj.close()


# import tabula
# # readinf the PDF file that contain Table Data
# # you can find find the pdf file with complete code in below
# # read_pdf will save the pdf table into Pandas Dataframe
# df = tabula.read_pdf('../w2/format_imges_diff/0064O00000jmlA5QAI-00P4O00001KS41hUAD-Sheila Dirks Dynamic 2017 W2.pdf')
# # in order to print first 5 lines of Table
# print(df)