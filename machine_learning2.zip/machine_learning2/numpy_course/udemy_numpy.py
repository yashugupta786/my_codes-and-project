import numpy as np
A=np.array([1,2,4,5])
print(A)
A=np.append(A,[6])
print(A)
A=A**2
print(A)
A=np.sqrt(A)
print(A)

#Dot Products in numpy'
a=np.array([1,2])
b=np.array([3,4])
c=np.dot(a,b)
print(c)