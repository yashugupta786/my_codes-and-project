from math import sqrt
# plot1=(1,3)
# plot2=(2,5)
# euclidean_distance=sqrt((plot1[0]-plot2[0])**2+(plot1[1]-plot2[1])**2)
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter
from matplotlib import style
style.use('fivethirtyeight')
import warnings
dataset={'k':[[1,2],[2,3],[3,1]],'r':[[6,5],[7,7],[8,6]]}
new_features=[5,7]
# for i in dataset:
#    for ii in dataset[i]:
#       data=plt.scatter(ii[0],ii[1],s=100,color=i)
# plt.show(data)
