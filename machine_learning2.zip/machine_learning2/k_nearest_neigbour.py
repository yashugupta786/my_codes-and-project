import pandas as pd
from sklearn import preprocessing,model_selection,neighbors
train_data = pd.read_csv('breast-cancer-wisconsin.data.txt', sep=",", header=None,names=['id','clump_thickness','unif_cell_size'
    ,'unif_cell_shape','marg_adhession','single_epith_cell_size'
    ,'bare_nuclei','bland_chromatin','normal_nucleoli','mitoses','class'])
print("there are {} rows and {} columns".format(train_data.shape[0],train_data.shape[1]))
train_data.replace('?',-99999,inplace=True)

train_data.drop(['id'],inplace=True,axis=1)
# print(train_data.head())
y=train_data['class']
# print(y.head())
train_data.drop(['class'],inplace=True,axis=1)
X=train_data

print(X.head())
# X_train,X_test,y_train,y_test=model_selection.train_test_split(X,y,test_size=0.2)
# # print(y_train)
# clf=neighbors.KNeighborsClassifier()
# clf.fit(X_train,y_train)
# accuracy=clf.score(X_test,y_test)
# print(accuracy)
# prediction=clf.predict(X_test)
# for i in prediction:
#     if i == 2:
#         print("benign cancer")
#     else:
#         print("maglignant cancer")
