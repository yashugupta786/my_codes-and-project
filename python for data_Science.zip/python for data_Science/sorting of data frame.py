import pandas as pd
movies=pd.read_csv("http://bit.ly/imdbratings")
movies.head()
"""
renaming columns
df.rename(columns={'':"","":""},inplace = True)

sorting of a series using different ways 

1  movies['title'].sort_values(ascending=False) returns only series

2 movies.sort_values("title",ascending=False) returns a full data frame
 
 Filtering of data frame by column value
data=[]
for i in movies.duration:
    if i>=200:
        data.append(True)
    else:
        data.append(False)
data[0:6]
        
        OR
        
        Querying 
new_data=movies.loc[movies.duration>=200,'title']
new_data

Mutilple queries using LOC pandas
new_data=movies.loc[(movies['duration'] > 200) & (movies['duration'] <= 229),['title','genre']]
new_data

new_data=movies.loc[(movies['duration'] >= 200) & (movies['duration'] <= 229) & (movies['content_rating']!='R') ,['title','genre']]
new_Data  
 
 iterrows
 for index,row in ufo.iterrows():
 print(index,row.city,row.state)
 ------------------------------------
how to select only number data set
import numpy as np
drinks.select_dtypes(include=[np.number]).dtypes
-----------------------------------------------
Group by clause 
drinks.groupby('continent').beer_servings.mean()
"""
'''
--->Handling missing data in pandas

ufo.isnull().tail()  returns in true and false 

ufo.dropna(how='all,any').shape
ufo['Shape Reported'].fillna(value='Various',inplace=True)
ufo['Shape Reported'].value_counts(dropna=False)


--->SElecting rows and columns
---->slicing in pandas
ufo.loc[0:4,:]
Ist parameter is rows that you want ,
ufo.loc[0:6,['City','State']]
2nd parameter is columns
'''








