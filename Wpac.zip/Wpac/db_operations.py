import re
import mysql.connector
from math import ceil

import server_settings

CONFIGURATION = {
    'user': "root",
    'password': "user",
    'host': "localhost",
    'database': "westpac",
}

RESPONSE_KEY = "response"
RESPONSE_VALUE = "An error occurred, please refer logs"

TABLE_PROCESS = "process"
TABLE_CATEGORY = "process_category"
TABLE_SUB_PROCESS = "sub_process"
TABLE_PROCESS_METRICS = "process_metrics"

COL_PROCESS_NAME = "process_name"
COL_PROCESS_DESC = "process_description"
COL_PROCESS_STATUS = "status"
COL_CATEGORY_NAME = "category_name"
COL_CATEGORY_DESC = "description"
COL_PRIORITY = "priority"
COL_PROCESS_ID = "process_id"

COL_STEP_DESC = "step_description"
COL_ACTIVITY_TYPE = "activity_type"
COL_INPUT_TYPE = "input_type"
COL_SYS_APPLICATION = "system_application"
COL_TIME_TAKEN = "time_taken"

COL_METRIC_CATEGORY = "metric_category"
COL_METRICS = "metrics"
COL_METRIC_VALUE = "value"
COL_METRIC_COUNTER = "counter"


# -------------------------------------------------------------------------------------#

def add_process(process_name, process_description):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)
    print "*************** add_process **************"
    process_id = ""
    try:
        flag = False
        cursor = connection.cursor(buffered=True)
        query = "INSERT INTO " + TABLE_PROCESS + \
                " ( " + \
                COL_PROCESS_NAME + " , " + \
                COL_PROCESS_DESC + " ) " + \
                " VALUES ( '%s','%s' )" % \
                (process_name, process_description)

        cursor.execute(query)

        if cursor.lastrowid > 0:
            flag = True

        if flag:
            print " Process Row successfully added"
            # return {RESPONSE_KEY: "Row successfully added"}
        else:
            print "Row failed to add"
            # return {RESPONSE_KEY: "Row failed to add"}

        query = "SELECT MAX(process_id) from " + TABLE_PROCESS
        cursor.execute(query)

        for row in cursor.fetchone():
            process_id = row

        return process_id

    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#

def add_category(category_name, category_description, priority, process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)
    print "*********** add_category *************"
    print category_name, category_description, priority, process_id
    try:
        flag = False
        cursor = connection.cursor(buffered=True)

        for i, category in enumerate(category_name):
            query = "INSERT INTO " + TABLE_CATEGORY + \
                    " ( " + \
                    COL_CATEGORY_NAME + " , " + \
                    COL_CATEGORY_DESC + " , " + \
                    COL_PRIORITY + " , " + \
                    COL_PROCESS_ID + " ) " + \
                    " VALUES ( '%s','%s','%s','%d' )" % \
                    (category_name[i], category_description[i], priority[i], process_id)

            print query

            cursor.execute(query)

            if cursor.lastrowid > 0:
                flag = True

            if flag:
                print "Category Row successfully added"
                # return {RESPONSE_KEY: "Row successfully added"}
            else:
                print "Row failed to add"
                # return {RESPONSE_KEY: "Row failed to add"}


    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        # connection = None
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#

def add_sub_process(json_req):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)

    print "******************* add_sub_process *****************"
    print "json_req: ", json_req

    process_id = json_req["process_id"]
    step_description = list(json_req["step_description"])
    activity_type = list(json_req["activity_type"])
    input_type = list(json_req["input_type"])
    sys_application = list(json_req["system_application"])
    time_taken = list(json_req["time_taken"])

    print "list: ", step_description

    try:
        flag = False
        cursor = connection.cursor(buffered=True)

        for i, step in enumerate(step_description):
            query = "INSERT INTO " + TABLE_SUB_PROCESS + \
                    " ( " + \
                    COL_STEP_DESC + " , " + \
                    COL_ACTIVITY_TYPE + " , " + \
                    COL_INPUT_TYPE + " , " + \
                    COL_SYS_APPLICATION + " , " + \
                    COL_TIME_TAKEN + " , " + \
                    COL_PROCESS_ID + " ) " + \
                    " VALUES ( '%s','%s','%s','%s','%d','%d' )" % \
                    (step_description[i], activity_type[i], input_type[i], sys_application[i], int(time_taken[i]),
                     process_id)

            print "sub process query -> ", query

            cursor.execute(query)

        if cursor.lastrowid > 0:
            flag = True

        if flag:
            print "Row successfully added"

        else:
            print "Row failed to add"

        # query to fetch count of rule based steps
        query = "SELECT COUNT(activity_type),activity_type FROM sub_process WHERE activity_type = 'Rule based'" \
                " and process_id = " + str(process_id) + " GROUP BY activity_type"

        print "Count Rule based steps query:", query
        cursor.execute(query)

        count_rule_based = 0
        for row in cursor:
            count_rule_based = row[0]
            print " count_rule_based: ", count_rule_based

        # query to fetch count of structured steps
        query = "SELECT  count(input_type),input_type from sub_process where input_type like 'Structured%' " \
                "and process_id = " + str(process_id) + " GROUP BY input_type"

        print "Count Structured steps query:", query
        cursor.execute(query)

        count_structured = 0
        for row in cursor:
            count_structured = row[0]

        # query to fetch count of total rows
        query = "SELECT COUNT(*) FROM " + TABLE_SUB_PROCESS + " WHERE process_id = " + str(process_id)
        print query
        cursor.execute(query)

        count_total_row = 0
        for row in cursor:
            count_total_row = row[0]
            print "count_total_row: ", count_total_row

        perc_rule_based_steps = round(((float(count_rule_based) / float(count_total_row)) * 100), 0)
        print"% of rule_steps: ", perc_rule_based_steps

        perc_structured_template = round(((float(count_structured) / float(count_total_row)) * 100), 0)
        print "% structured_template", perc_structured_template

        final_dict = {"rule_based": perc_rule_based_steps, "structured_template": perc_structured_template,
                      "keystroke_level": count_total_row}

        return final_dict

    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#

def calc_rfactor(process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)
    print "************ calc r factor called *****************"
    final_dict = dict()
    try:
        cursor = connection.cursor(buffered=True)

        query = "SELECT step_id, time_taken, activity_type, input_type FROM " \
                + TABLE_SUB_PROCESS + " WHERE process_id = %d " % process_id

        print query
        cursor.execute(query)

        step_list = []
        time_taken = []
        combination = []
        efforts = []
        rfactor_reference = []
        r_factor = 0

        for row in cursor:
            print row
            step_list.append(row[0])
            time_taken.append(row[1])
            temp = str(row[2]).lower() + ", " + str(row[3]).lower()
            print temp
            combination.append(temp)

        #query to get sum of all time_taken in a process
        query = "SELECT SUM(time_taken) FROM " + TABLE_SUB_PROCESS + " WHERE process_id = %d " % process_id
        print query
        cursor.execute(query)

        total_time_taken = 0
        for row in cursor:
            total_time_taken = row[0]

        print "total_time_taken ", total_time_taken

        for i, time in enumerate(time_taken):
            effort_perc = round((float(time_taken[i]) / float(total_time_taken)) * 100, 2)
            print "effort_perc ", effort_perc
            efforts.append(effort_perc)

        for i, x in enumerate(combination):
            query = "SELECT r_factor FROM combination WHERE combination = '%s'" % str(combination[i])
            print "combination query :", query
            cursor.execute(query)

            for row in cursor:
                rfactor_reference.append(row[0])

        for i, ref in enumerate(rfactor_reference):
            print "efforts[i] * rfactor_reference[i] :", efforts[i], rfactor_reference[i]
            r_factor += ((efforts[i] * rfactor_reference[i]) / 100)

        r_factor = round(r_factor, 0)
        total_time_taken = round(float(total_time_taken) / 60, 0)

        final_dict['r_factor'] = r_factor
        final_dict['aht_min'] = total_time_taken

        return final_dict

    except Exception as exception:  # LOGGER.exception(exception)
        print "error happnd :", str(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#
def add_metrics_data(json_req):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)

    print "************ add_metrics_data **************"
    print "json_req: ", json_req

    process_id = json_req["process_id"]
    metric_category = json_req["metric_category"]
    metrics = list(json_req["metrics"])
    value = list(json_req["priority"])
    counter = 1

    try:
        flag = False
        cursor = connection.cursor(buffered=True)

        for i, metric in enumerate(metrics):
            query = "INSERT INTO " + TABLE_PROCESS_METRICS + \
                    " ( " + \
                    COL_METRIC_CATEGORY + " , " + \
                    COL_METRICS + " , " + \
                    COL_METRIC_VALUE + " , " + \
                    COL_PROCESS_ID + " , " + \
                    COL_METRIC_COUNTER + " ) " + \
                    " VALUES ( '%s','%s','%d','%d','%d' )" % \
                    (metric_category, metrics[i], int(value[i]), process_id, counter)

            counter += 1

            print "add metric query -> ",query

            cursor.execute(query)

            if cursor.lastrowid > 0:
                flag = True

            if flag:
                print "Metric Row successfully added"
                # return {RESPONSE_KEY: "Row successfully added"}
            else:
                print "Row failed to add"
                # return {RESPONSE_KEY: "Row failed to add"}

    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#

def get_process_info(process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)
    print "get info"
    try:
        cursor = connection.cursor(buffered=True)
        query = "SELECT * FROM " + TABLE_PROCESS + " WHERE process_id = %d " % process_id
        print query
        cursor.execute(query)

        count = -1
        final_dict = dict()

        for row in cursor:
            final_dict = {COL_PROCESS_ID: row[0],
                          COL_PROCESS_NAME: row[1],
                          COL_PROCESS_DESC: row[2]}

        print "Process info :- ",final_dict

        return final_dict

    except Exception as exception:
        # LOGGER.exception(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# -------------------------------------------------------------------------------------#

def get_all_process():
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)
    print "all process"
    try:
        cursor = connection.cursor(buffered=True)
        query = "SELECT * FROM " + TABLE_PROCESS
        print query
        cursor.execute(query)

        count = -1
        final_dict = dict()
        process_list = []

        for row in cursor:
            temp_dict = {COL_PROCESS_ID: row[0],
                         COL_PROCESS_NAME: row[1],
                         COL_PROCESS_DESC: row[2],
                         COL_PROCESS_STATUS: row[3]}

            process_list.append(temp_dict)

        final_dict['process_list'] = process_list

        return final_dict

    except Exception as exception:
        # LOGGER.exception(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# --------------------------------------------------------------------------------------#

def calc_business_priority_result(process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)

    print 'helo'
    sum_category = 0
    sum_business_priority = 0
    business_criticality = 0

    cursor = connection.cursor(buffered=True)

    try:

        # query to fetch business critical metrics
        query = "SELECT * FROM " + TABLE_PROCESS_METRICS + \
                " where metric_category LIKE '%Priority%' and process_id =  " + str(process_id)

        print query
        cursor.execute(query)

        count = -1
        final_dict = dict()
        metric_list = []

        for row in cursor:
            temp_dict = {"process_id": row[1],
                         "metric_category": row[2],
                         "metrics": row[3],
                         "value": int(row[4])}

            if temp_dict["value"] == 5:
                temp_dict["value"] = 1

            elif temp_dict["value"] == 4:
                temp_dict["value"] = 0.8

            elif temp_dict["value"] == 3:
                temp_dict["value"] = 0.6

            elif temp_dict["value"] == 2:
                temp_dict["value"] = 0.4

            elif temp_dict["value"] == 1:
                temp_dict["value"] = 0.2

            else:
                temp_dict["value"] = 0

            metric_list.append(temp_dict)

        print metric_list

        query = "SELECT category_name,description,priority FROM " + TABLE_CATEGORY + \
                " where process_id = " + str(process_id)

        print query

        cursor.execute(query)

        category_list = []
        # head_rows = cursor.fetchmany(size=1)

        for row in cursor:
            temp_dict = {"category_name": row[0],
                         "description": row[1],
                         "priority": int(row[2])
                         }

            category_list.append(temp_dict)
            # return final_dict

        print "length", len(category_list), len(metric_list)

        temp_core_category = 0
        temp_core_metric = 0
        #
        print "category_list"
        for category in category_list:
            print category
        print "---------------------------"
        print "metric_list"
        for metric in metric_list:
            print metric
        # print "---------------------------"


        for i in range(len(metric_list)):
            for j in range(len(category_list)):
                # print "working"

                if re.search(r'\b' + str(metric_list[i]["metrics"]).lower() + r'\b',
                             str(category_list[j]["description"]).lower()):
                    print metric_list[i]["metrics"], category_list[j]["description"], metric_list[i]["value"], \
                        category_list[j]["priority"]

                    sum_category = round(sum_category + (metric_list[i]["value"] * category_list[j]["priority"]), 2)

        # sum_category = round(sum_category + (temp_core_category * temp_core_metric), 2)

        query = "SELECT SUM(priority) FROM process_category where category_name like " \
                "'Business%' and process_id = " + str(process_id)

        print query
        cursor.execute(query)

        for row in cursor:
            sum_business_priority = row[0]

        print 'sum business priority: ', sum_business_priority
        print 'sum category  : ', sum_category

        business_criticality = int((float(sum_category) / float(sum_business_priority) * 100))

        print 'business criticality :', business_criticality

        final_dict['business_criticality'] = business_criticality

        return final_dict

    except Exception as exception:
        print str(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# --------------------------------------------------------------------------------------#

def calc_operation_efficiency(process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)

    cursor = connection.cursor(buffered=True)
    total_fte = 0
    total_working_hours = 0
    productivity = 0
    no_onshore_fte = 0
    no_offshore_fte = 0
    billing_onshore = 0
    billing_offshore = 0
    no_working_hours = 0
    aht_min = 0
    volume_per_yr = 0
    final_dict = dict()

    try:
        # query to fetch business critical metrics
        query = "SELECT * FROM " + TABLE_PROCESS_METRICS + \
                " where metric_category LIKE '%Rapid%' and process_id =  " + str(process_id)

        print query
        cursor.execute(query)

        metric_list = []
        for row in cursor:
            temp_dict = {"process_id": row[1],
                         "metric_category": row[2],
                         "metrics": row[3],
                         "value": int(row[4]),
                         "counter": int(row[5])}

            metric_list.append(temp_dict)

        for i in range(len(metric_list)):
            if i < 2:
                total_fte = float(total_fte + metric_list[i]['value'])

            if metric_list[i]['counter'] == 1:
                no_onshore_fte = float(metric_list[i]['value'])

            if metric_list[i]['counter'] == 2:
                no_offshore_fte = metric_list[i]['value']

            if metric_list[i]['counter'] == 3:
                no_working_hours = metric_list[i]['value']

            if metric_list[i]['counter'] == 4:
                billing_onshore = metric_list[i]['value']

            if metric_list[i]['counter'] == 5:
                billing_offshore = metric_list[i]['value']

            if metric_list[i]['counter'] == 6:
                aht_min = metric_list[i]['value']

            if metric_list[i]['counter'] == 7:
                volume_per_yr = metric_list[i]['value']

            if metric_list[i]['counter'] == 9:
                productivity = metric_list[i]['value']

        total_working_hours = (no_working_hours * 12 * 21)

        productivity = float(productivity) / 100
        print "productivity value (R factor) ", productivity

        # manual_hours_saved = round((float(total_fte * total_working_hours * productivity)), 2)
        manual_hours_saved = round((float(volume_per_yr * aht_min * productivity) / 60), 0)
        print "manual_hours_saved ", manual_hours_saved

        # cost_saved = ((no_onshore_fte * billing_onshore) + (no_offshore_fte * billing_offshore)) * productivity * 12
        cost_saved = round((float(manual_hours_saved) / 2100) * billing_onshore,0)
        print "cost_saved ", cost_saved

        no_production_license_req = round((float(total_fte * productivity) / 1.4), 2)

        no_production_license_req = ceil(no_production_license_req)

        print total_fte, total_working_hours, productivity

        print manual_hours_saved, cost_saved, no_production_license_req

        final_dict["manual_hours_saved"] = manual_hours_saved

        final_dict["cost_saved"] = cost_saved

        final_dict["no_production_license_req"] = no_production_license_req

        return final_dict

    except Exception as exception:
        print str(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# --------------------------------------------------------------------------------------#

def calc_complexity_rating(process_id):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.WESTPAC_DB)

    # variables----------------------------------------------------------------------------
    complexity_rating = 0

    perc_rule_value = 0
    perc_std_value = 0
    perc_HW = 0
    voice_call = ""
    app_refered = ""
    steps_stable = ""
    keystroke_level = 0
    screen_referred = 0
    portal_referred = ""
    field_referred = 0
    no_app = 0
    lic_based = ""

    # constants------------------------------------------------------------------------------
    Percent_Rule_Steps = 20
    Percent_Std_Str_Input = 17
    Percent_Scan_HW = 15
    Voice_call_inv_low_val = "No"
    Percent_Voice_Calls = 12
    stable_app_high_val = "Yes"
    stable_app_low_val = "No"
    Percent_Stable_Proc = 8
    stable_proc_steps_high_val = "Yes"
    stable_proc_steps_low_val = "No"
    Percent_Stable_Steps = 7
    No_keystr_low_val = 51
    No_keystr_high_val = 200
    Percent_No_Keystr_steps = 6
    No_scr_app_low_val = 15
    No_scr_app_high_val = 30
    Percent_No_scr = 5
    Third_party_low_val = "No"
    Percent_Third_party_app = 4
    No_fields_match_process_low_val = 21
    No_fields_match_process_high_val = 50
    Percent_No_fields = 3
    No_app_low_val = 5
    No_app_high_val = 8
    Percent_No_app = 2
    Lic_sw_inv_low_val = "No"
    Percent_Lic_SW = 1

    # --------------------------------------------------------------------------------------#
    print "calc_complexity_rating called-------------------"
    cursor = connection.cursor(buffered=True)

    query = "SELECT * FROM " + TABLE_PROCESS_METRICS + " WHERE metric_category like '%Complexity' and process_id = " \
            + str(process_id)

    print query
    cursor.execute(query)
    metric_list = []

    for row in cursor:
        temp_dict = {"metrics": row[3],
                     "value": row[4],
                     "counter": row[5]}

        metric_list.append(temp_dict)

    for i, metric in enumerate(metric_list):
        # D4
        if metric_list[i]['counter'] == 1:
            perc_rule_value = float(metric_list[i]['value'])

        # D5
        if metric_list[i]['counter'] == 2:
            perc_std_value = float(metric_list[i]['value'])

        # D6
        if metric_list[i]['counter'] == 3:
            # perc_HW = float(metric_list[i]['value']) / 100
            perc_HW = float(metric_list[i]['value'])

        # D7
        if metric_list[i]['counter'] == 4:
            if metric_list[i]['value'] == 1:
                voice_call = 'Yes'
            else:
                voice_call = 'No'

        # D8
        if metric_list[i]['counter'] == 5:
            if metric_list[i]['value'] == 1:
                app_refered = 'Yes'
            else:
                app_refered = 'No'

        # D9
        if metric_list[i]['counter'] == 6:
            if metric_list[i]['value'] == 1:
                steps_stable = 'Yes'
            else:
                steps_stable = 'No'

        # D10
        if metric_list[i]['counter'] == 7:
            keystroke_level = metric_list[i]['value']

        # D11
        if metric_list[i]['counter'] == 8:
            screen_referred = metric_list[i]['value']

        # D12
        if metric_list[i]['counter'] == 9:
            if metric_list[i]['value'] == 1:
                portal_referred = 'Yes'
            else:
                portal_referred = 'No'

        # D13
        if metric_list[i]['counter'] == 10:
            field_referred = metric_list[i]['value']

        # D14
        if metric_list[i]['counter'] == 11:
            no_app = metric_list[i]['value']

        # D15
        if metric_list[i]['counter'] == 12:
            if metric_list[i]['value'] == 1:
                lic_based = 'Yes'
            else:
                lic_based = 'No'

    # ------------------------------- calculations ---------------------------------------------#

    if (perc_rule_value == 0):
        perc_rule_value = 100

    step1 = (100 - perc_rule_value) * Percent_Rule_Steps

    print "step1", perc_rule_value, Percent_Rule_Steps, step1

    if (perc_std_value == 0):
        perc_std_value = 100

    step2 = (100 - perc_std_value) * Percent_Std_Str_Input

    print "step2", perc_std_value, Percent_Std_Str_Input, step2

    if perc_HW == 0:
        perc_HW = 0

    step3 = (perc_HW * Percent_Scan_HW)
    print "step3", perc_HW, Percent_Scan_HW, step3

    voice_value = 0
    if voice_call == "No":
        voice_value = 0
    else:
        voice_value = 1

    step4 = voice_value * Percent_Voice_Calls
    print "step4", voice_value, Percent_Voice_Calls, step4

    app_refered_value = 0
    if app_refered == stable_app_high_val:
        app_refered_value = 0
    elif app_refered == stable_app_low_val:
        app_refered_value = 1

    step5 = app_refered_value * Percent_Stable_Proc
    print"step5", app_refered_value, Percent_Stable_Proc, step5

    step_stable_value = 0
    if steps_stable == stable_proc_steps_high_val:
        step_stable_value = 0
    elif steps_stable == stable_proc_steps_low_val:
        step_stable_value = 1

    step6 = step_stable_value * Percent_Stable_Steps
    print "step6", step_stable_value, Percent_Stable_Steps, step6

    keystroke_value = 0
    if keystroke_level != 0:
        if keystroke_level < No_keystr_low_val:
            keystroke_value = 0.25
        elif keystroke_level <= No_keystr_high_val and keystroke_level >= No_keystr_low_val:
            keystroke_value = 0.5
        else:
            keystroke_value = 0.75

    step7 = keystroke_value * Percent_No_Keystr_steps
    print"step7", keystroke_value, Percent_No_Keystr_steps, step7

    screen_referred_value = 0
    if screen_referred != 0:
        if screen_referred < No_scr_app_low_val:
            screen_referred_value = 0.25
        elif screen_referred <= No_scr_app_high_val and screen_referred >= No_scr_app_low_val:
            screen_referred_value = 0.5
        else:
            screen_referred_value = 0.75

    step8 = screen_referred_value * Percent_No_scr
    print "step8", screen_referred_value, Percent_No_scr, step8

    portal_referred_value = 0
    if portal_referred == Third_party_low_val:
        portal_referred_value = 0
    else:
        portal_referred_value = 1

    step9 = portal_referred_value * Percent_Third_party_app
    print "step9", portal_referred_value, Percent_Third_party_app

    field_referred_value = 0
    if field_referred != 0:
        if field_referred < No_fields_match_process_low_val:
            field_referred_value = 0.25
        elif field_referred <= No_fields_match_process_high_val and field_referred >= No_fields_match_process_low_val:
            field_referred_value = 0.5
        else:
            field_referred_value = 0.75

    step10 = field_referred_value * Percent_No_fields
    print "step10" ,field_referred_value ,Percent_No_fields

    no_app_value = 0
    if no_app != 0:
        if no_app < No_app_low_val:
            no_app_value = 0.25
        elif no_app <= No_app_high_val and no_app >= No_app_low_val:
            no_app_value = 0.5
        else:
            no_app_value = 0.75

    step11 = no_app_value * Percent_No_app
    print "step11" ,no_app_value , Percent_No_app

    lic_based_value = 0
    if lic_based == Lic_sw_inv_low_val:
        lic_based_value = 0
    else:
        lic_based_value = 1

    step12 = lic_based_value * Percent_Lic_SW
    print "step12",lic_based_value ,Percent_Lic_SW

    complexity_rating = step1 + step2 + step3 + step4 + step5 + step6 + step7 + step8 + step9 + step10 + step11 + step12

    complexity_rating = round(float(complexity_rating)/100, 0)
    print "complexity_rating ", complexity_rating

    complexity_perc = float(complexity_rating) / 100

    complexity_auto = " "
    design_dev = " "
    uat_timeline = " "

    if complexity_perc <= 0.25:
        complexity_auto = "Low"
        design_dev = "3-4 weeks"
        uat_timeline = "1-2 weeks"

    elif complexity_perc > 0.25 and complexity_perc <= 0.75:
        complexity_auto = "Medium"
        design_dev = "4-5 weeks"
        uat_timeline = "2-3 weeks"
    else:
        complexity_auto = "High"
        design_dev = "6-8 weeks"
        uat_timeline = "4-5 weeks"

    return {"complexity_rating": complexity_rating,
            "complexity_auto": complexity_auto, "design_dev": design_dev, "uat_timeline": uat_timeline}

# --------------------------------------------------------------------------------------#

# print calc_business_priority_result(135)
# print calc_rfactor(136)
# print calc_complexity_rating(12)
