import os
import json
import bottle
from bottle import post, get, run, request, response, route, static_file, error
import server_settings
import db_operations

RESPONSE_KEY = "response"
RESPONSE_VALUE = "An error occurred, please refer logs"


def enable_cors(decoratorfn):
    """
    Cross Origin Resource Sharing
    :param decoratorfn:
    :return:
    """

    def _enable_cors(*args, **kwargs):
        # set CORS headers
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, ' \
                                                           'Content-Type, X-Requested-With, ' \
                                                           'X-CSRF-Token'
        response.headers['Content-Type'] = 'application/json'
        if request.method != 'OPTIONS':
            return decoratorfn(*args, **kwargs)

    return _enable_cors


app = bottle.default_app()


# -------------------------------------------------------------------------------------#
@get("/getAllProcessData")
@enable_cors
def get_all_process_data():
    json_data = db_operations.get_all_process()

    return json_data


# -------------------------------------------------------------------------------------#
@post("/addProcessData")
@enable_cors
def add_process_data():
    json_req = dict(request.json)
    # print json_req

    process_name = json_req["process_name"]
    process_description = json_req["process_description"]
    category_list = list(json_req["category_name"])
    category_desc_list = list(json_req["category_description"])
    priority_list = list(json_req["priority"])

    final_dict = dict()

    try:
        process_id = db_operations.add_process(process_name, process_description)

        print process_id

        db_operations.add_category(category_list, category_desc_list, priority_list, process_id)

        final_dict = db_operations.get_process_info(process_id)

        json_obj = json.dumps(final_dict)

        return json_obj

    except Exception as e:
        return {RESPONSE_KEY: type(e)}


# -------------------------------------------------------------------------------------#
@post("/addSubProcessData")
@enable_cors
def add_sub_process_data():
    json_req = dict(request.json)
    # print "Data Received"

    process_id = json_req["process_id"]
    print process_id

    dict1 = db_operations.add_sub_process(json_req)

    dict2 = db_operations.get_process_info(process_id)

    dict3 = db_operations.calc_rfactor(process_id)

    final_dict = dict2.copy()
    final_dict.update(dict1)
    final_dict.update(dict3)

    print "subprocess response ------", final_dict
    json_obj = json.dumps(final_dict)

    return json_obj


# -------------------------------------------------------------------------------------#
@post("/addMetricsData")
@enable_cors
def upload_metric_data():
    json_req = dict(request.json)

    db_operations.add_metrics_data(json_req)

    return {RESPONSE_KEY: "success"}


# -------------------------------------------------------------------------------------#
@post("/getFinalOutput")
@enable_cors
def get_output():
    json_req = dict(request.json)

    process_id = json_req["process_id"]

    dict1 = db_operations.calc_business_priority_result(process_id)

    dict2 = db_operations.get_process_info(process_id)

    dict3 = db_operations.calc_operation_efficiency(process_id)

    dict4 = db_operations.calc_complexity_rating(process_id)

    final_dict = dict2.copy()
    final_dict.update(dict1)
    final_dict.update(dict3)
    final_dict.update(dict4)

    print "************ final output ******************* ", final_dict


    return final_dict


# -------------------------------------------------------------------------------------#

@app.error(404)
def error404(error):
    """
    File not present error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'Sorry there is nothing here'})


@app.error(500)
def error500(error):
    """
    Request Format error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'There was Processing problem make sure your request type is POST'
                                     ' and has Content-Type:application/json in header'})


@app.error(428)
def error428(error):
    """
    JSON format error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'Improper json Structure or Json key missing'})


@app.route("/")
def index():
    """

    :return:
    """
    return static_file('index.html', root='./static')


@app.route('/static/<filepath:path>')
def server_static(filepath):
    """

    :param filepath:
    :return:
    """
    return static_file(filepath, root='./static')


# TODO :: Comment while deployment
# create_dirc()
HOST_NAME = os.getenv("VCAP_APP_HOST", server_settings.WP_SERVER_IP)
PORT_NUMBER = int(os.getenv("VCAP_APP_PORT", server_settings.WP_SERVER_PORT))
run(host=HOST_NAME, port=PORT_NUMBER, server='paste')
