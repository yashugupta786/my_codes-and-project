from sklearn.pipeline import Pipeline
from sklearn import preprocessing, svm

# training_data=[]
# labels=[]
# with open("intention_learning_5500.txt", "r") as file_obj:
#     for all_data in file_obj:
#         new_train_data=all_data.split("|")
#         training_data.append(new_train_data[1].strip())
#         labels.append(new_train_data[0].strip())

level=['yashu','yashu','anjali','boggu','prerna','boggu']
LABEL_ENCODER_DATA = preprocessing.LabelEncoder()
LABEL_ENCODER_DATA.fit(level)

interpretation_all_data = LABEL_ENCODER_DATA.transform(level)
print(interpretation_all_data)
#
#
