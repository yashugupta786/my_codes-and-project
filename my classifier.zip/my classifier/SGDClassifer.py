import json

# import mysql.connector
from bs4 import BeautifulSoup
from sklearn.decomposition import RandomizedPCA
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from nltk.corpus import wordnet as wn
import nltk
from sklearn.grid_search import GridSearchCV
from sklearn.linear_model import SGDClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC

from sklearn import metrics

from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn import preprocessing, svm

import string
import numpy as np

stemmer = nltk.stem.SnowballStemmer('english')


# _ corpus = [
# _     'This is the first document.',
# _     'This is the second second document.',
# _     'And the third one.',
# _     'Is this the first document?',
# _ ]

# corpus = [u'How much is the contribution towards Provident Fund?',
#           u'I want to know about my Provident Fund deduction',
#           u'What deductions are made towards Provident Fund?',
#           u'What is the deduction for Provident Fund?',
#           u'What amount goes into Provident fund?',
#
#           u'What is Voluntary Provident Fund, how can I make additional contribution?',
#           u'What is the process for Voluntary Provident Fund contribution?',
#           u'Who do I contact in case I want to make Voluntary Contribution to the Provident Fund?',
#           u'What is the process to apply for Voluntary contribution amount to my Provident Fund?',
#           u'Tell me the steps to contribute additional sum to my Provident fund',
#
#           u'Is my Provident Fund account managed by RPFC or Genpact?',
#           u'Where is my Provident Fund contribution deposited?',
#           u'Where is Provident Fund and FPF deposited?',
#           u'Where is Family pension fund deposited?',
#           u'where do we save our Provident Fund contribution?',
#
#           u'How can I withdraw my Provident Fund?',
#           u'How can I apply for my Provident fund amount?',
#           u'What is the process to get Provident Fund amount?',
#           u'What are the steps for Provident Fund amount withdrawal?',
#
#           u'How can I withdraw my Provident Fund for the Purchase of house?',
#           u'Can I apply for my Provident Fund Loan to purchase a house property?',
#           u'Please tell the steps to apply for Provident Fund to buy a house property',
#           u'What is the process to apply for Provident Fund amount for the purchase of house?',
#           u'What documents are required to apply for Provident Fund amount to purchase a house property?',
#
#           u'Can I withdraw  my Provident Fund under medical emergency?',
#           u'Can I apply for Provident Fund loan for treatment of illness?',
#           u'Please tell the process to apply for Provident Fund in order to get medical treatment',
#           u'I want to know the Provident Fund withdrawal process in case of medical emergency.',
#           u'What documents are required to apply for Provident Fund amount under medical exigency?',
#
#           u'I need information regarding tax deduction in Provident Fund withdrawal',
#           u'What membership is required to avoid tax deduction on Provident Fund amount?',
#           u'Is my Provident Fund amount tax exempted?',
#           u'Which documents is required for the calculation of tax?',
#           u'Is there any tax deduction on Provident Fund amount?',
#           ]
#
#
#
# interpretation_all_data = np.array([1, 1, 1, 1, 1,
#                                     2, 2, 2, 2, 2,
#                                     3, 3, 3, 3, 3,
#                                     4, 4, 4, 4,
#                                     5, 5, 5, 5, 5,
#                                     6, 6, 6, 6, 6,
#                                     7, 7, 7, 7, 7], dtype=int)









_training = []
_interpretation = []


def get_training_data_and_interpretation():
    training_data = []
    interpretation_data = []
    with open("intention_learning_5500.txt", "r") as file_obj:
        for line in file_obj:
            line_data = line.split("|")
            training_data.append(line_data[1].strip())
            interpretation_data.append(line_data[0].strip())
            # print(training_data)

    return training_data, interpretation_data

training_data, interpretation_data = get_training_data_and_interpretation()
# print(training_data)#traing dataset
print(interpretation_data)#labels

LABEL_ENCODER_DATA = preprocessing.LabelEncoder()
LABEL_ENCODER_DATA.fit(interpretation_data)#encodes the data and creates lables by using the transform method
interpretation_all_data = LABEL_ENCODER_DATA.transform(interpretation_data)
print(interpretation_all_data)

# for sentence in corpus:
#     question1 = filter_question_by_pos(sentence)
#     question1 = get_stemmed_sentence(question1.lower())
#     question1 = replace_by_dictionary(question1)
#     training_data.append(question1)


count_vectorizer = CountVectorizer(ngram_range=(1, 2))

# X = count_vectorizer.fit_transform(training_data)
#
# features = count_vectorizer.get_feature_names()
# data = X.toarray()

# for single_data, single_question in zip(data, training_data):
#     print "Question: %s " % single_question
#     print single_data
#
# print features
# print data



# MNB Classifier
# TEXT_CLASSIFIER1 = Pipeline([('vect', count_vectorizer),
#                              ('clf', MultinomialNB(alpha=1.0,
#                                                    class_prior=None,
#                                                    fit_prior=True,
#                                                    ))])


# SGD Classifier
TEXT_CLASSIFIER1 = Pipeline([
                            ('vectorizer', count_vectorizer),
                            ('clf', SGDClassifier(loss='modified_huber',
                                                  alpha=1e-3,
                                                  n_jobs=-1,
                                                  n_iter=1000,
                                                  shuffle=True))
                            ])


parameters = {

              }


# model_tuning = GridSearchCV(TEXT_CLASSIFIER1, parameters, verbose=1, n_jobs=-1)

TEXT_CLASSIFIER = TEXT_CLASSIFIER1.fit(training_data, interpretation_all_data)

#
# print TEXT_CLASSIFIER.best_score_
# print TEXT_CLASSIFIER.best_params_
#


def fetch_interpreted_q(query):
    """
    this functions predicts the interpreted question for a given query
    :param query: a model and a label encorder for the model
    :return: a interpreted query class
    """
    #
    print(query)
    otherq = []
    scores = []
    pred = TEXT_CLASSIFIER.predict(query)
    inter_q = LABEL_ENCODER_DATA.inverse_transform(pred)
    return inter_q


question = ""
while question != "exit()":
    print ("\n\n")
    question = input("Enter Sentence: ")

    query = [question]
    # print (question)
    print ("\n")

    inter_q = (fetch_interpreted_q(query))
    print (inter_q[0])
