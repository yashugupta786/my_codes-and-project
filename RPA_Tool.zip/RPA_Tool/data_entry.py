import xlrd
import re
import mysql.connector
import server_settings

TABLE_FEATURE_QUESTION = "feature_questions"

wb = xlrd.open_workbook('data.xlsx')

sh = wb.sheet_by_name('Sheet4')

print sh

qid = []
question = []
feature = []
decs = []
tool = []
AA = []
bp = []
ui = []
pega = []
rda = []
wf = []
type = []
rm = []
r = []
ml = []
f_id = []

for rownum in range(1, sh.nrows):
    row_values = sh.row_values(rownum)
    if qid is None:
        print "break"
        break
    else:
        qid.append(row_values[0])
        question.append(row_values[1])
        feature.append(row_values[2])
        decs.append(row_values[3])
        tool.append(row_values[4])
        AA.append(row_values[5])
        bp.append(row_values[6])
        ui.append(row_values[7])
        pega.append(row_values[8])
        rda.append(row_values[9])
        wf.append(row_values[10])
        type.append(row_values[11])
        rm.append(row_values[12])
        r.append(row_values[13])
        ml.append(row_values[14])
        f_id.append(row_values[15])

connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                     password=server_settings.MYSQL_PWD,
                                     host=server_settings.MYSQL_HOST,
                                     database=server_settings.RPA_DB)

cursor = connection.cursor()
try:
    print 'helo'
    for i, category in enumerate(qid):
        print int(f_id[i])
        if qid not in [None, "", " "]:
            query = "INSERT INTO " + TABLE_FEATURE_QUESTION + " (`qid`, `question`, `product_feature`, `description`,`tool_desc`, " \
                    "`AA`, `bp_ver`, `uipath_ver`, `pega_robotics`, `pega_rda`, `workfusion_spa`, `automation_type`, `rm`, `r`, `robotics`,`feature_id`) " \
                    "VALUES (%s, '%s', '%s', '%s', '%s', %s, %s, %s, %s, %s, %s, '%s', '%s', '%s', '%s',%s)" % (
                        int(qid[i]), question[i], feature[i], decs[i], tool[i],
                        int(AA[i]), int(bp[i]), int(ui[i]), int(pega[i]), int(rda[i]), int(wf[i]), type[i], rm[i], r[i],
                        ml[i], int(f_id[i]))

        print query
        cursor.execute(query)


except Exception as exception:
    print str(exception)
    connection.rollback()
finally:
    connection.commit()
    connection.close()
