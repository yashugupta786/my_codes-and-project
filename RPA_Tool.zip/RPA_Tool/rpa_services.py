import os
import json
import bottle
from bottle import post, get, run, request, response, route, static_file, error
import server_settings
import db_operations

RESPONSE_KEY = "response"
RESPONSE_VALUE = "An error occurred, please refer logs"


def enable_cors(decoratorfn):
    """
    Cross Origin Resource Sharing
    :param decoratorfn:
    :return:
    """

    def _enable_cors(*args, **kwargs):
        # set CORS headers
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, ' \
                                                           'Content-Type, X-Requested-With, ' \
                                                           'X-CSRF-Token'
        response.headers['Content-Type'] = 'application/json'
        if request.method != 'OPTIONS':
            return decoratorfn(*args, **kwargs)

    return _enable_cors


app = bottle.default_app()


# -------------------------------------------------------------------------------------#
@post("/addStep1Data")
@enable_cors
def add_step1_data():
    print "add step data"
    json_req = list(request.json)
    print json_req
    json_data = db_operations.add_step1_data(json_req)

    return json_data


# -------------------------------------------------------------------------------------#

@post("/addStep2Data")
@enable_cors
def add_step1_data():
    print "add step2 data"
    json_req = request.json
    print json_req
    user_id = json_req["user_id"]

    json_data = db_operations.add_step2_data(json_req)

    print json_data

    return json_data


# -------------------------------------------------------------------------------------#

@get("/getQuestions")
@enable_cors
def get_questions():
    json_data = db_operations.get_question_data()
    return json_data


# -------------------------------------------------------------------------------------#

@get("/getFeatureQuestions")
@enable_cors
def get_questions():
    json_data = db_operations.get_feature_question_data()
    return json_data

# -------------------------------------------------------------------------------------#

@post("/getFinalOutput")
@enable_cors
def add_step1_data():
    print "final output"
    json_req = dict(request.json)
    print json_req
    json_data = db_operations.calc_final_output(json_req)

    print json_data

    return json_data


# -------------------------------------------------------------------------------------#

@app.error(404)
def error404(error):
    """
    File not present error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'Sorry there is nothing here'})


@app.error(500)
def error500(error):
    """
    Request Format error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'There was Processing problem make sure your request type is POST'
                                     ' and has Content-Type:application/json in header'})


@app.error(428)
def error428(error):
    """
    JSON format error
    :param error:
    :return:
    """
    response.content_type = 'application/json'
    return json.dumps({RESPONSE_KEY: 'Improper json Structure or Json key missing'})


@app.route("/")
def index():
    """

    :return:
    """
    return static_file('index.html', root='./static')


@app.route('/static/<filepath:path>')
def server_static(filepath):
    """

    :param filepath:
    :return:
    """
    return static_file(filepath, root='./static')


# TODO :: Comment while deployment
# create_dirc()
HOST_NAME = os.getenv("VCAP_APP_HOST", server_settings.WP_SERVER_IP)
PORT_NUMBER = int(os.getenv("VCAP_APP_PORT", server_settings.WP_SERVER_PORT))
run(host=HOST_NAME, port=PORT_NUMBER, server='paste')
