import json
import re

import collections
import mysql.connector

import server_settings

RESPONSE_KEY = "response"
RESPONSE_VALUE = "An error occurred, please refer logs"

TABLE_STEP1_DATA = "step1_data"
TABLE_STEP2_DATA = "step2_data"
TABLE_QUESTION_DATA = "question_data"
TABLE_FEATURE_CATEGORY = "feature_category"
TABLE_FEATURE_QUESTION = "feature_questions"

COL_QID = "qid"
COL_QUESTION = "question"
COL_OPTION_ID = "option_id"
COL_SEL_OPTION = "selected_option"
COL_USER_ID = "user_id"
COL_OPTION = "options"

COL_QUESTION_ID = "question_id"

COL_FEATURE_ID = "feature_id"
COL_FEATURE_NAME = "feature_name"

COL_ANSWER = "answer"


# -------------------------------------------------------------------------------------#
def add_step1_data(json_req):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.RPA_DB)
    user_id = 0

    try:
        cursor = connection.cursor(buffered=True)
        cursor.execute("SELECT MAX(user_id) from step1_data")

        print cursor.rowcount

        for row in cursor:
            if row[0]:
                user_id = row[0] + 1
            else:
                user_id = 1

        for i, obj in enumerate(json_req):
            qid = json_req[i]["QuestionID"]
            option = json_req[i]["OptionName"]

            query = "INSERT INTO " + TABLE_STEP1_DATA + \
                    " ( " + \
                    COL_QID + " , " + \
                    COL_SEL_OPTION + " , " + \
                    COL_USER_ID + " ) " + \
                    "VALUES ( %d,'%s',%d)" % \
                    (qid, option, user_id)

            cursor.execute(query)

            return {COL_USER_ID: user_id}

    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#
def add_step2_data(json_req):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.RPA_DB)

    try:

        cursor = connection.cursor(buffered=True)

        user_id = json_req["user_id"]
        answer_list = list(json_req["Data"])

        for answer in answer_list:
            temp_dict = dict(answer)
            feature_id = int(temp_dict["FeatureID"])
            qid = int(temp_dict["QuestionID"])
            answer = temp_dict["OptionName"]

            query = "INSERT INTO " + TABLE_STEP2_DATA + \
                    " ( " + \
                    COL_FEATURE_ID + " , " + \
                    COL_QID + " , " + \
                    COL_ANSWER + " , " + \
                    COL_USER_ID + " ) " + \
                    "VALUES ( %d,%d,'%s',%d)" % \
                    (feature_id, qid, answer, user_id)

            print query

            cursor.execute(query)

        return {RESPONSE_KEY: "success"}

    except Exception as exception:
        # LOGGER.exception(exception)
        print "error happnd :", exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.commit()
        connection.close()


# -------------------------------------------------------------------------------------#
def get_question_data():
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.RPA_DB)
    print "get_question_data"
    try:
        cursor = connection.cursor(buffered=True)
        query = "SELECT * FROM " + TABLE_QUESTION_DATA
        cursor.execute(query)

        question_list = []
        final_dict = dict()

        for row in cursor:
            temp_dict = {COL_QUESTION_ID: row[0],
                         COL_QUESTION: row[1],
                         COL_OPTION: list(row[2].split(","))}
            question_list.append(temp_dict)

        final_dict["questions"] = question_list

        return final_dict

    except Exception as exception:
        # LOGGER.exception(exception)
        print exception
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# -------------------------------------------------------------------------------------#
def get_feature_question_data():
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.RPA_DB)
    print "get feature question"
    try:
        cursor = connection.cursor(buffered=True)
        query = "SELECT * FROM " + TABLE_FEATURE_CATEGORY
        cursor.execute(query)

        feature_list = []
        final_dict = dict()

        for row in cursor:
            feature_id = int(row[0])
            temp_feature_dict = {COL_FEATURE_ID: row[0],
                                 COL_FEATURE_NAME: row[1]
                                 }

            cursor_db = connection.cursor()
            query = "SELECT qid , question FROM " + TABLE_FEATURE_QUESTION + " WHERE " + \
                    COL_FEATURE_ID + " = %d" % feature_id
            cursor_db.execute(query)
            question_list = []
            for r in cursor_db:
                temp_question_dict = {COL_QID: r[0],
                                      COL_QUESTION: r[1]}

                question_list.append(temp_question_dict)

            temp_feature_dict["questions"] = question_list

            print temp_feature_dict

            feature_list.append(temp_feature_dict)

        final_dict["questions"] = feature_list

        return final_dict

    except Exception as exception:
        # LOGGER.exception(exception)
        print str(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()


# -------------------------------------------------------------------------------------#
def calc_final_output(json_req):
    connection = mysql.connector.connect(user=server_settings.MYSQL_USER,
                                         password=server_settings.MYSQL_PWD,
                                         host=server_settings.MYSQL_HOST,
                                         database=server_settings.RPA_DB)

    AA_tool = 0
    blue_prism = 0
    UI_path = 0
    pega_robotics = 0
    work_fusion = 0
    pega_RDA = 0
    count_question = 0

    user_id = json_req["user_id"]

    result_list = []

    try:
        cursor = connection.cursor(buffered=True)
        query = "SELECT count(question) FROM " + TABLE_FEATURE_QUESTION
        cursor.execute(query)

        for row in cursor:
            count_question = row[0]

        print "count of questions : ", count_question
        count_question *= 5

        query = "SELECT feature_id ,qid FROM " + TABLE_STEP2_DATA + " WHERE answer = 'Yes' AND user_id = " + str(
            user_id)
        print query
        cursor.execute(query)

        for row in cursor:
            feature_id = int(row[0])
            qid = int(row[1])

            cursor_db = connection.cursor()

            query = "SELECT AA, bp_ver, uipath_ver, pega_robotics, pega_rda, workfusion_spa FROM " + \
                    TABLE_FEATURE_QUESTION + " WHERE qid = " + str(qid) + " AND feature_id =  " + str(feature_id)

            print query

            cursor_db.execute(query)

            for r in cursor_db:
                AA_tool += r[0]
                blue_prism += r[1]
                UI_path += r[2]
                pega_robotics += r[3]
                pega_RDA += r[4]
                work_fusion += r[5]

        print AA_tool,blue_prism,UI_path,pega_robotics,pega_RDA,work_fusion

        AA_tool = round( (float(AA_tool)/float(count_question)) * 100,0)
        blue_prism = round((float(blue_prism)/float(count_question)) * 100,0)
        UI_path = round((float(UI_path)/float(count_question)) * 100,0)
        pega_robotics = round((float(pega_robotics)/float(count_question)) * 100,0)
        pega_RDA = round((float(pega_RDA)/float(count_question)) * 100,0)
        work_fusion = round((float(work_fusion)/float(count_question)) * 100,0)

        temp_dict = {"Automation Anywhere": AA_tool,
                     "Blue Prism": blue_prism,
                     "UI Path": UI_path,
                     "Pega Robotics": pega_robotics,
                     "Work Fusion": work_fusion,
                     "Pega RDA": pega_RDA}

        print "temp_dict : ", temp_dict

        sorted_dict = collections.OrderedDict(sorted(temp_dict.items(), key=lambda x: (-x[1], x[0])))

        counter = 1
        for key, value in sorted_dict.items():
            final_dict = collections.OrderedDict()
            final_dict["Title"] = key
            final_dict["cData"] = value
            final_dict["Rank"] = ("Rank " + str(counter))
            final_dict["TotalScore"] = count_question
            counter += 1
            result_list.append(final_dict)

        json_data = json.dumps(result_list)

        print json_data

        return json_data

    except Exception as exception:
        # LOGGER.exception(exception)
        print str(exception)
        connection.rollback()
        return {RESPONSE_KEY: RESPONSE_VALUE}
    finally:
        connection.close()

# calc_final_output(84)
